# Energy Lighthouse v0.4 — Integrationsbericht

## Status

Dieser Ausbau ist ein lokaler Forschungs-/Engineering-Prototyp im Sandkasten und **keine Zertifizierung, keine Netzfreigabe und kein Nachweis für KRITIS-, Rechts- oder Versorgungssicherheitseignung**. Alle Ausgaben enthalten diese Evidenzgrenze.

## Umgesetzte Schritte

1. **Datensatzintegration:** `data/energy_lighthouse_working_data_0.1.json` wurde byteidentisch in die Architektur übernommen. Der Loader prüft geschlossene Top-Level-Struktur, doppelte JSON-Schlüssel, exakt 8.760 Stunden, Pflichtfelder, Kapazitätsfaktoren und regionale Nachfrageanteile. Nutzerparameter, Modellannahmen und synthetische Zeitreihen bleiben als getrennte Rollen sichtbar.
2. **Integrierter Rechenkern:** `energy_lighthouse/integrated.py` koppelt vier deutsche Modellregionen, Stromnachfrage, Wärmelast/Wärmepumpenanteil, EV-Last, flexible Nachfrage, PV, Onshore-/Offshore-Wind, Batterien, aggregierte Interkonnektoren, nationalen Import, H₂-Elektrolyse/Speicher/Rückverstromung, Kosten, CO₂ und Loss-of-Load-Auswertung.
3. **Vergleich und Assurance:** `catalog` enumeriert 6 Szenarien × (Baseline + 6 Stressereignisse) = 42 deterministische Fälle. Die Auswertung enthält Worst-Service-, Niedrig-CO₂- und Niedrigkostenfälle. Die Argus-Tests und ein read-only Inventar wurden ausgeführt.

## Reproduzierbare Befehle

```bash
cd Apophis-erneuerbare
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -v
python3 -m energy_lighthouse integrated data/energy_lighthouse_working_data_0.1.json \
  --scenario-id climate_neutrality_2045 --out runs/v0.4-integrated-2045-final
python3 -m energy_lighthouse catalog data/energy_lighthouse_working_data_0.1.json \
  --out runs/v0.4-integrated-catalog
```

## Ausgeführte Evidenz

- **27/27** Python-Regressionstests bestanden.
- **42/42** Katalogfälle berechnet; keine Wahrscheinlichkeiten vergeben.
- Vollständiger 8.760-Stunden-Lauf für `climate_neutrality_2045` erzeugt unter `runs/v0.4-integrated-2045-final/`.
- Dieser Lauf meldet 95,7005 % Stromservice, 0,957 MWh nicht gedeckte Gesamtstromlast, 404.616.944 MWh_th nicht gedeckte Wärme in der gewählten Modellkonfiguration, 580.594.923 kg H₂-Erzeugung und 38.089.257.920 kg angenommene netzbezogene CO₂-Emissionen. Diese Zahlen sind Modelloutput, keine empirische Prognose.
- Argus-Toolkit: 5/5 Argus-Regressionstests und 1/1 Hardening-Test bestanden; Assurance `PASS_WITH_LIMITATIONS`, `not_a_certification=true`.
- Read-only-Inventar ausgeführt; Zielartefakte wurden während der Auditphase nicht verändert.

## Datenherkunft und Grenzen

Die 8.760 Profile tragen `SYNTHETIC_TEST_DATA`; Modellannahmen tragen `ILLUSTRATIVE_WORKING_ASSUMPTIONS`; der Referenzblock trägt `REFERENCE_PARAMETERS_USER_SUPPLIED` und ist nicht unabhängig validiert. Die mitgelieferten Beispielquellen in `data/verified_samples/` wurden nicht automatisch zu amtlichen Eingangsdaten erklärt.

Die Netze sind aggregierte Transportkanten und kein AC/DC-Leistungsfluss. Es gibt keine N-1-, Frequenz-, Spannungs-, Rampen-, Mindestlast- oder Redispatchprüfung. Der Dispatch ist greedy und nicht LP/MILP-optimal. EV- und H₂-Größen sowie der Wärmepumpenanteil sind explizite Arbeitsannahmen und benötigen Fachreview. Kosten und CO₂ sind keine vollständige Lebenszyklusrechnung. Ausfallereignisse sind deterministische Stressfälle ohne Eintrittswahrscheinlichkeiten.

## Nächster Ausbau außerhalb dieses abgeschlossenen Dreischritts

Für einen belastbaren Planungsstand wären ein geprüftes deutsches Regionalnetzmodell, zeitgekoppelte Speicher-/Flexibilitätsoptimierung, explizite H₂-Nachfrage und Infrastrukturrestriktionen, probabilistische Adequacy-Analysen, empirisch validierte Wetter-/Lastjahre, unabhängige Modellvalidierung und eine separate Sicherheits-/Netzstudie erforderlich.
