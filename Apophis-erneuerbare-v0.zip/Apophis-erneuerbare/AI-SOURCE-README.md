# AI Source Package — Energy Lighthouse v0.7

Dieses Verzeichnis ist ein zusammengeführtes, lokales Forschungsarchiv. Für eine KI-Auswertung gilt `AI-SOURCE-MANIFEST.json` als maschinenlesbare Quellen- und Prioritätsdefinition.

## Quellenpriorität

1. `data/energy_lighthouse_working_data_0.1.json` ist die primäre Arbeitsquelle für den integrierten Rechenkern. Sie enthält 8.760 synthetische Stundenprofile, Szenarien, Stressereignisse und Modellannahmen. Sie ist **keine reale Messdatenquelle**.
2. `data/verified_samples/` enthält gebündelte, attribuierte Referenzdaten und Originalarchive. Diese Daten sind Referenzmaterial und werden vom Rechenkern nicht automatisch als deutsche Eingangsdaten interpretiert.
3. `examples/` enthält kleine synthetische Demonstrationsfälle für den bestehenden Modellkern.
4. `runs/` enthält reproduzierte Modelloutputs. Diese Dateien sind Ergebnisse, nicht Eingangsquellen.
5. `assurance/` enthält das bereitgestellte Argus-Red-Team-/Assurance-Toolkit und seine Prüfartefakte. Es ist ein Prüfwerkzeug, kein Energiedatensatz.

## Verbindliche Interpretation

Eine KI darf synthetische Profile und illustrative Annahmen nicht als historische, amtliche oder gemessene Werte darstellen. Jede abgeleitete Aussage muss die verwendete Datei und ihre Datenrolle nennen. Prüfsummen, Dateipfade, Szenario-ID, Stress-ID und Laufverzeichnis sollen bei Auswertungen erhalten bleiben.

Die Modellgrenzen sind verbindlich: aggregierter Transport statt AC/DC-Leistungsfluss, keine N-1-/Frequenz-/Spannungsprüfung, deterministischer Dispatch beziehungsweise begrenzte Design-Sweeps statt globaler LP/MILP-Optimierung und keine unabhängige fachliche Validierung. Das Archiv ist nicht zertifiziert und nicht für reale Infrastrukturentscheidungen freigegeben.

## Einstieg für KI-Systeme

Zuerst `AI-SOURCE-MANIFEST.json`, danach `README.md`, `INTEGRATION-REPORT-v0.4.md` und die Blockberichte lesen. Für die aktuelle Modelllogik `energy_lighthouse/integrated.py` verwenden. Für reproduzierbare Ergebnisse die CLI-Befehle in `README.md` nutzen. Für Quellenattribution und Lizenzhinweise `data/verified_samples/DATASET-MANIFEST.json` lesen.
