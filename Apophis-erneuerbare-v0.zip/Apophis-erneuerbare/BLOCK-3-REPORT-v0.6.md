# Energy Lighthouse v0.6 — Block-3-Bericht

## Netzmodell

Die bisherige proportionale Sammelverteilung wurde durch gerichtete Interkonnektorflüsse auf den fünf im Datensatz gelieferten Kanten ersetzt. Jede Kante prüft Quelle, Ziel, Kapazität und Verlustfaktor. Der Bericht speichert gesendete Energie, gelieferte Energie, Leitungsverlust und die im jeweiligen Zeitintervall verwendete Kapazität.

Der Stressfall `interconnector_loss_48h` setzt die Transportkapazität deterministisch auf null. Die Energiebilanz bleibt dabei erhalten; fehlende Transportmöglichkeiten wirken sich auf Importbedarf und nicht gedeckte Last aus. Das Modell bleibt ausdrücklich ein aggregiertes Transportmodell und kein AC/DC-Leistungsfluss.

## Versorgungssicherheit

Jede Stunde berechnet nun eine statische Reserveanforderung als konfigurierbaren Anteil der gekoppelten Nachfrage. Als Reserveproxy werden ungenutztes nationales Importlimit und ungenutzte H₂-Rückverstromungsleistung berücksichtigt. Ausgegeben werden Mindestreserve, Reservekurzfallenergie und Reservekurzfallstunden.

Im 24-Stunden-Basistest wurden 16 Reservekurzfallstunden, eine Mindestreserve von 2.000 MW sowie 141.368,4 MWh gelieferter Interkonnektoraustausch mit 3.576,88 MWh Transportverlust ausgewiesen. Diese Kennzahlen sind keine Frequenz-, Rampen-, N-1- oder Netzstabilitätsnachweise.

## Nachweise

`PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -q` ergibt **29/29 bestanden**. Der 24-Stunden-Lauf liegt unter `runs/v0.6-network-reserve/`; die Bilanzprüfung meldet `demand_balance_pass: true`.

Read-only-Inventar und die bereits ausgeführten Argus-Checks bleiben Bestandteil der Gesamt-Evidenz. Der Rechenkern ist weiterhin R1-Prototyp, nicht zertifiziert und nicht für reale Infrastrukturentscheidungen freigegeben.
