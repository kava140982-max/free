# Lokale Beispieldaten im ZIP

Diese Dateien sind als kleine, quellengebundene Entwicklerproben enthalten. Sie sind keine reale Szenariokonfiguration und wurden nicht in die stündliche Modellrechnung umgewandelt. Prüfsummen stehen in `DATASET-MANIFEST.json`.

| Datei | Inhalt / Verwendung | Herkunft und Nutzungsrahmen |
|---|---|---|
| `pglib_opf_case14_ieee.m` | Kleiner IEEE-14-Bus-AC-OPF-Benchmark im MATPOWER-Format; Benchmark, keine gemessene Netzzeitreihe. | PGLib-OPF Maintainer-Repository, Datei nennt CC BY 4.0. [Originaldatei](https://github.com/power-grid-lib/pglib-opf/blob/master/pglib_opf_case14_ieee.m) · [Lizenz](https://creativecommons.org/licenses/by/4.0/) |
| `geoscience_australia_electricity_infrastructure.zip` | Original-GIS-Download von Leitungen/Umspannwerken in Australien. ZIP-Inhalt hier absichtlich nicht entpackt. | Geoscience Australia, CC BY 4.0; Attribution beibehalten. [Katalog/Metadaten](https://pid.geoscience.gov.au/dataset/ga/151179) · [Lizenz](https://creativecommons.org/licenses/by/4.0/) |
| `nlr_hydrogen_historical_wind_sample.zip` | NLR-Archiv mit 1-Hz-Messreihe des Elektrolyseurs und Windprofil; siehe auch die kleine, attribuierte Beispieldatensatzzeile unten. | National Laboratory of the Rockies/US DOE, Data Submission 316. NLR-Datasetlizenz erlaubt kostenfreie Nutzung/Kopie unter Erhalt des Lizenzhinweises; Credit ist bei Veröffentlichungen mit Datennutzung erforderlich. Daten „as is“, Gewährleistungsausschluss. [Datensatz](https://data.nlr.gov/submissions/316) · [NLR-Lizenz](https://data.nlr.gov/node/316/license) |

## Ein geprüfter NLR-Beispieldatensatz

`nlr_hydrogen_example_record.csv` überträgt eine konkrete, zuvor aus der NLR-Original-CSV gelesene Zeile in sprechende Spaltennamen. Der Zeitstempel wird unverändert als Quelltext wiedergegeben; die geprüften Metadaten belegten für diese Zeile keine Zeitzone. Leistungswerte und H₂-Massenstrom sind Quelleingaben; `derived_specific_electricity_kwh_per_kg` ist ein abgeleiteter Quotient und **keine unabhängige Messung**. Diese Einzelzeile ist kein Ersatz für die unveränderte CSV im NLR-ZIP.

## Bewusst nicht mitgelieferte Quellen

WPuQ (HDF5) ist ein 459-MB-Rohdatenfile; When2Heat ist eine ca. 328-MB-Datei. Sie sind im Quellenbericht beschrieben und direkt verlinkt, aber nicht in dieses kleine ZIP übernommen. Die EIA-923-Arbeitsmappe wurde wegen unklar ausgewiesener Lizenz nicht gebündelt. Der SHIFDR-Eintrag nennt keine konkrete CC-Lizenzvariante. PECD-Hydro ist ebenfalls direkt verlinkt; die Datei wurde nach dem Abbruch der Abrufe nicht lokal aufgenommen. Für diese Quellen gelten die jeweiligen Originalmetadaten, nicht die drei lokalen Proben.
