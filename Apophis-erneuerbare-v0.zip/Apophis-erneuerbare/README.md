# Energy Lighthouse — lokaler Energiesystem-Prototyp 0.3.0

Ein reproduzierbarer Python-Rechenkern für stündliche regionale Energieflüsse. Er umfasst Stromnachfrage, PV/Wind, Batteriespeicher, Netzbezug, einen optionalen Brennstoffgenerator sowie eine einfache Wärmepumpe mit thermischer Last. Die eingebauten Profile sind synthetisch und nicht extern validiert. Das Modell ist keine vollständige Energiesystemplattform, Netzstudie oder Planungsfreigabe.

## Schnellstart

Voraussetzung: Python 3.10 oder neuer. Keine Drittanbieterpakete nötig.

```bash
cd energy-lighthouse
python3 -m unittest discover -s tests -v
python3 -m energy_lighthouse simulate examples/reference.json --out runs/reference
python3 -m energy_lighthouse simulate examples/heat-pump-demo.json --out runs/heat-pump
python3 -m energy_lighthouse simulate examples/time-varying-reserve-demo.json --out runs/outages
python3 -m energy_lighthouse stress examples/reference.json --out runs/stress
python3 -m energy_lighthouse sensitivity examples/reference.json \
  --demand-scales 0.9,1.0,1.1 --renewable-scales 0.8,1.0,1.2 \
  --grid-price-scales 0.8,1.0,1.2 --out runs/sensitivity
python3 -m energy_lighthouse sweep examples/pareto-tradeoff.json \
  --capacities 0,2,4,8,12,16 --powers 0,1,2,3,4 --out runs/pareto
python3 -m energy_lighthouse import-csv examples/reference-profile.csv \
  --out runs/imported-scenario.json --interval-hours 1
```

Eine Simulation erzeugt `report.json`, `hourly.csv`, `summary.md` und die bytegenaue `scenario.input.json`. Sensitivitäts- und Sweep-Berichte archivieren ebenfalls ihre Eingabe. SHA-256 belegt Byte-Identität, nicht Datenrichtigkeit.

## Implementierte Funktionen

1. **Strombilanz und Speicher:** erneuerbare Erzeugung, Netzverluste, Batterieeffizienz/SOC/Selbstentladung sowie Versorgungsbilanz.
2. **Brennstoff-Backup:** explizite Leistung, Verfügbarkeit, Wirkungsgrad, Brennstoff-/O&M-Kosten, Emissionen und CAPEX.
3. **Wärmepumpen-Kopplung:** thermische Nachfrage in MW_th, thermische Nennleistung, fester COP und thermische Deckung. Strombedarf fließt in die Strombilanz ein; bei Engpässen wird die Wärmepumpe vor der elektrischen Grundlast abgeregelt.
4. **Zeitabhängige Verfügbarkeit:** Generator und Netz können pro Zeitintervall Verfügbarkeitsfaktoren von 0 bis 1 erhalten.
5. **Zuverlässigkeitskennzahlen:** nicht gedeckte elektrische MWh, Loss-of-Load-Stunden/Ereignisse und Spitzenlastabwurf. Wärmedefizite werden getrennt ausgewiesen.
6. **Einfache Reserveprüfung:** ungenutzte Netz-, Generator- und Batterie-Leistung wird einer eingegebenen Reserveanforderung gegenübergestellt.
7. **Deterministische Sensitivität:** vollständiges Produkt aus Nachfrage-, Erneuerbaren- und Netzpreisfaktoren, begrenzt auf 2.000 Fälle; keine Monte-Carlo-Wahrscheinlichkeiten.
8. **Diskreter Speichervergleich:** Kosten-, Versorgungs-, Wärme- und Emissionsziele mit Paretofront über das vorgegebene Raster.
9. **Eingabe/Prüfbarkeit:** strikte JSON-/CSV-Prüfung, UTC-Zeitstempelprüfung, Hashes, Szenario-Snapshots, Tests und CSV-/JSON-Exporte.

## Datenmodell und Annahmen

Leistungen sind MW, Wärmepumpenleistung MW_th, Intervallenergien MWh bzw. MWh_th. Zeitauflösungen von Teilstunden bis 24 Stunden sind rechnerisch zugelassen. Der CSV-Import verlangt `demand_mw,pv_mw,wind_mw`, optional `timestamp` und `thermal_demand_mw_th`. Zeitstempel müssen ISO-8601 mit UTC-Offset, monoton und gleichmäßig sein. Importierte Profile erhalten zunächst editierbare Standardwerte, unter anderem keine installierte Batterie oder Wärmepumpe.

Der elektrische Dispatch ist eine myopische Heuristik: Erneuerbare decken zuerst den Bedarf, Überschüsse können die Batterie laden, und die Batterie wird bei Defiziten nach einer einfachen Regel entladen. Danach werden thermischer Generator und Netz nach variablen Kosten sortiert. Die Wärmepumpe verwendet einen zeitlich konstanten COP und ist vollständig unterbrechbar; reale Vorlauftemperaturen, Gebäudeträgheit, Mindestlaufzeiten und Komfortgrenzen fehlen.

Verfügbarkeitsreihen sind vorgegebene Szenarioeingaben, keine geschätzten Ausfallwahrscheinlichkeiten. Die Reservekennzahl ist nur eine statische Leistungsmargen-Näherung aus verbliebener Netz-, Generator- und Batterie-Leistung. Sie bildet weder Reaktionszeit, Rampen, Netzrestriktionen noch N-1-, Frequenz- oder Spannungsstabilität ab. LOLE/EENS sind Profilkennzahlen, keine statistischen Erwartungswerte.

Kosten werden für ein 365-Tage-Äquivalent berechnet, indem das Eingabeprofil gleichförmig wiederholt wird; es gibt keine Jahressimulation. Batteriedegradation, Generatorstarts, Mindestlasten, Rampen und Emissionslebenszyklen fehlen. Alle Wirkungsgrade, Preise und Emissionsfaktoren sind ausdrücklich Annahmen, sofern sie nicht für ein konkretes Szenario mit Quellen belegt wurden.

## Beispiele

- `examples/reference.json`: synthetischer 24-Stunden-Stromfall mit Batterie und Generator.
- `examples/heat-pump-demo.json`: synthetischer Wärme-/Wärmepumpenfall mit konstantem COP.
- `examples/time-varying-reserve-demo.json`: synthetische Stundenprofile für Netz- und Generatorverfügbarkeit sowie eine angenommene Reserve.
- `examples/pareto-tradeoff.json`: synthetische Preissensitivität für den Kosten-/Emissionszielkonflikt.
- `examples/reference-profile.csv`: synthetische UTC-CSV-Zeitreihe.

Für verifizierbare externe Datensätze siehe [DATA-SOURCE-RESEARCH.md](DATA-SOURCE-RESEARCH.md), sobald die Quellenprüfung abgeschlossen ist. Die Verfügbarkeit in einer Behördendatenbank macht eine Reihe nicht automatisch fehlerfrei oder für jedes Modell geeignet.

## Noch nicht implementiert

Keine AC/DC-Leistungsfluss- oder Stabilitätsanalyse, geografische Netzmodellierung, Kernenergie- oder Wasserkraftmodelle, eingebundene externe Wetterdaten, Monte-Carlo- oder Mehrjahreschronologien, statistische Ausfallwahrscheinlichkeiten, kontinuierliche LP/MILP-Optimierung, GUI, Speicherdegradation, Umweltlebenszyklusanalyse oder unabhängige Ergebnisvalidierung. Wasserstoff, EV, flexible Verbraucher und Design-Sweep sind als deterministische Arbeitsmodelle vorhanden, nicht als validierte Planung. Nicht für reale Infrastrukturentscheidungen ohne Fachprüfung und geeignete externe Modelle einsetzen.

## ZIP-Herkunft

`Apophis-Argus-RedTeam-Toolkit-Hardened.zip` ist ein allgemeines Prüf-/Modul-Toolkit und kein Energiesystemmodell. Seine Skripte wurden nicht ausgeführt. Übernommen wurden nur passende Arbeitsweisen: strikte Eingabevalidierung, klare Evidenzgrenzen, reproduzierbare Berichte und automatisierte Tests.


## Mitgelieferte Quelldatenproben

Das ZIP enthält drei vollständige, lizenz-/attributionsdokumentierte Beispielquellen sowie eine verifizierte Elektrolyseur-Beispielzeile unter [`data/verified_samples/`](data/verified_samples/README.md). Die ZIP-Archive werden absichtlich nicht entpackt oder als Projektkonfiguration ausgegeben. Prüfsummen stehen im Datenmanifest. Weitere Quellen und Grenzen sind in [DATA-SOURCE-RESEARCH.md](DATA-SOURCE-RESEARCH.md) beschrieben.

## Integrierter Ausbau v0.4

Der vollständige Arbeitsdatensatz liegt unverändert unter `data/energy_lighthouse_working_data_0.1.json`. Der neue Rechenkern `energy_lighthouse/integrated.py` koppelt vier Regionen, Strom/Wärme, EV- und flexible Last, PV/Wind, Batterien, aggregierte Netzkanten, nationalen Import, Wasserstofferzeugung/-speicherung/-rückverstromung, Kosten, CO₂ und deterministische Stressfälle. Die Datensatzrollen bleiben im Ergebnis sichtbar; synthetische Profile und illustrative Annahmen werden nicht als reale Messdaten ausgegeben.

```bash
python3 -m energy_lighthouse integrated data/energy_lighthouse_working_data_0.1.json \
  --scenario-id climate_neutrality_2045 --out runs/v0.4-integrated-2045-final
python3 -m energy_lighthouse catalog data/energy_lighthouse_working_data_0.1.json \
  --out runs/v0.4-integrated-catalog
```

Der Kataloglauf vergleicht 42 deterministische Fälle. Die Erweiterung ist ein R1-Prototyp und keine Zertifizierung; aggregierter Transport ersetzt keinen AC/DC-Leistungsfluss, und der Dispatch ist keine globale Optimierung. Details, Tests und Auditbefunde stehen in `INTEGRATION-REPORT-v0.4.md` und `AUDIT-REPORT-v0.4.md`.
