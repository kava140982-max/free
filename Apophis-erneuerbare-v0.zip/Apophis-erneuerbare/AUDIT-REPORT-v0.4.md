# Read-only-Audit — Energy Lighthouse v0.4

**Auditmodus:** lokal, read-only; keine Zielartefakte während der Auditphase verändert. **Klassifikation:** R1 working prototype. **Nicht zertifiziert.**

## Ausführungsnachweise

- Inventar: `/home/ubuntu/skills/forensic-system-builder/scripts/inventory_readonly.sh Apophis-erneuerbare`
- Anwendungstests: `PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -v` → 27/27 bestanden.
- Argus-Tests: `python3 -m unittest discover -s argus-100/tests -p 'test_*.py'` → 5/5 bestanden; Hardening → 1/1 bestanden.
- Assurance: `python3 argus-100/scripts/run_assurance.py argus-100` → `PASS_WITH_LIMITATIONS`, nicht zertifiziert.
- Vollständiger Lauf: `runs/v0.4-integrated-2045-final/`, 8.760 Intervalle.

## Befunde

### F-0001 — Aggregiertes Netzmodell statt physikalischem Lastfluss

- **Severity:** High
- **Evidenzstatus:** Confirmed
- **Evidenz:** `energy_lighthouse/integrated.py`, Dokumentation im Rückgabefeld `limitations`; `network_model_level` im Arbeitsdatensatz ist `aggregated_interregional_transport_not_AC_power_flow`.
- **Erwartete Eigenschaft:** Engpässe, grenzüberschreitender Handel und Versorgungssicherheit müssen physikalisch belastbar geprüft werden.
- **Beobachtung:** Die Implementierung summiert Transportkapazitäten und verteilt Austausch proportional; Spannungs-/Frequenzgrenzen, Kirchhoff-Gleichungen, N-1 und Redispatch fehlen.
- **Konsequenz:** Netzengpässe und Versorgungssicherheit können falsch positiv oder falsch negativ bewertet werden.
- **Reproduktion:** `python3 -m energy_lighthouse integrated ...` und Inspektion der `limitations` im `result.json`.
- **Remediation:** Geprüftes nodales AC/DC-Modell mit validierten Netzparametern und unabhängigen Netzstudien einführen.
- **Restunsicherheit:** Größe der Abweichung ist mit synthetischen Daten nicht quantifizierbar.

### F-0002 — Deterministischer greedy Dispatch, keine Optimierungsgarantie

- **Severity:** High
- **Evidenzstatus:** Confirmed
- **Evidenz:** `energy_lighthouse/integrated.py`, Docstring `deterministic greedy dispatch`; `catalog.json` bezeichnet Fälle ausdrücklich als deterministisch.
- **Erwartete Eigenschaft:** Versorgungskonzepte sollten für Kosten, Emissionen und Versorgung gemeinsam optimiert werden.
- **Beobachtung:** Die Reihenfolge ist eine transparente Heuristik; keine LP/MILP-, Unit-Commitment- oder Mehrperiodenoptimierung.
- **Konsequenz:** Kosten, Speicherreichweite, Flexibilitätswert und Ausbauvergleiche sind keine globalen Optima.
- **Reproduktion:** `python3 -m energy_lighthouse catalog ...` und Ergebnisfeld `limitations`.
- **Remediation:** Validiertes Optimierungsmodell mit expliziten Nebenbedingungen und Optimalitäts-/Gap-Berichten ergänzen.
- **Restunsicherheit:** Abweichung hängt von den gewählten Parametern ab.

### F-0003 — H₂-, EV- und Wärmepumpenparameter teilweise Arbeitsannahmen

- **Severity:** Medium
- **Evidenzstatus:** Confirmed
- **Evidenz:** `IntegratedOptions` in `integrated.py`; Ergebnisfeld `data_evidence.source_roles`; Datensatzstatus `ILLUSTRATIVE_WORKING_ASSUMPTIONS`.
- **Erwartete Eigenschaft:** Sektorübergreifende Bilanzen müssen auf validierten Nachfrage- und Technologieparametern beruhen.
- **Beobachtung:** Der H₂-Speicher, die Rückverstromungsleistung, der EV-Anteil und der Wärmepumpenanteil sind explizite Defaults bzw. Optionen.
- **Konsequenz:** H₂- und Sektorkopplungsergebnisse sind Szenarioannahmen, nicht belastbare Prognosen.
- **Reproduktion:** `result.json` → `limitations` und `data_evidence`.
- **Remediation:** Fachlich freigegebene Parameterprofile und separate H₂-/EV-Nachfragesalden versionieren.
- **Restunsicherheit:** Die Parameterwirkung ist quantitativ aus den ausgegebenen Stundenreihen nachvollziehbar, ihre Richtigkeit nicht.

### F-0004 — Fehlende unabhängige fachliche Validierung

- **Severity:** Medium
- **Evidenzstatus:** Confirmed
- **Evidenz:** Datensatzmetadata `WORKING_BASELINE_NOT_INDEPENDENTLY_VALIDATED`; lokaler Testbericht; Argus meldet `PASS_WITH_LIMITATIONS`.
- **Erwartete Eigenschaft:** Ergebnisfreigabe sollte unabhängige Replikation, Quellen- und Domänenreview enthalten.
- **Beobachtung:** Es gibt lokale Regressionen und Reproduzierbarkeit über SHA-256, aber keine externe Identitätsprüfung, signierte Provenienz oder unabhängige Netz-/Energiefachprüfung.
- **Konsequenz:** Ein grüner Testlauf beweist weder fachliche Richtigkeit noch Konformität.
- **Reproduktion:** Argus-Assurance-Report und `INTEGRATION-REPORT-v0.4.md`.
- **Remediation:** Unabhängige Reviewer, validierte Quellen, signierte Build-/Datenprovenienz und Vergleich gegen Referenzmodelle ergänzen.
- **Restunsicherheit:** Externe Validierung wurde im Sandkasten nicht durchgeführt.

## Positive, direkt belegte Eigenschaften

- Doppelte JSON-Schlüssel und unbekannte Datensatzstruktur werden abgewiesen.
- Das Arbeitsdatenpaket wird vollständig mit 8.760 Stunden geladen und seine Rollen bleiben sichtbar.
- Unbekannte Szenario- und Stress-IDs werden fail-closed abgewiesen.
- Bestehende 23 Regressionstests plus 4 neue Integrationstests bestehen.
- 42 Szenario-/Stressfälle werden deterministisch reproduzierbar ausgewertet.
- Input-Snapshots und SHA-256-Hashes werden in den Läufen gespeichert.

## Nicht geprüft / nicht bewiesen

Keine Produktionsbereitstellung, kein echter Netzanschluss, keine externe Identitätsprüfung, keine signierte Attestierung, kein AC/DC-Lastfluss, keine N-1- oder Frequenzstabilität, keine probabilistische Adequacy, keine Rechts-/KRITIS-Konformität und keine Zertifizierung.
