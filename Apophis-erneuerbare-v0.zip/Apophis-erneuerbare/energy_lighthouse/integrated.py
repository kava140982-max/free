"""Integrated regional energy-system model driven by the supplied working-data package.

This is a deterministic research model, not a grid-security study or certification.
All values originating from the working package retain their evidence/data-role labels.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import hashlib, json, math

INTEGRATED_VERSION = "0.1.0"
class IntegratedModelError(ValueError): pass

def _num(x: Any, name: str, minimum: float | None = None) -> float:
    if isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(float(x)):
        raise IntegratedModelError(f"{name} must be finite numeric")
    y = float(x)
    if minimum is not None and y < minimum: raise IntegratedModelError(f"{name} must be >= {minimum}")
    return y

def _sha(path: Path) -> str: return hashlib.sha256(path.read_bytes()).hexdigest()

def load_working_data(path: str | Path) -> tuple[dict[str, Any], str]:
    p = Path(path); raw = p.read_bytes()
    if len(raw) > 50_000_000: raise IntegratedModelError("working dataset exceeds 50 MB safety limit")
    def pairs(ps):
        out = {}
        for k,v in ps:
            if k in out: raise IntegratedModelError(f"duplicate JSON key: {k}")
            out[k] = v
        return out
    data = json.loads(raw.decode("utf-8"), object_pairs_hook=pairs)
    if not isinstance(data, dict): raise IntegratedModelError("dataset root must be an object")
    required = {"metadata","user_supplied_reference_parameter_baseline","working_model_assumptions","scenario_catalog","stress_event_library","synthetic_hourly_profiles_2025"}
    if set(data) != required: raise IntegratedModelError(f"dataset sections mismatch: {sorted(set(data)^required)}")
    rows = data["synthetic_hourly_profiles_2025"].get("rows")
    if not isinstance(rows, list) or len(rows) != 8760: raise IntegratedModelError("exactly 8760 hourly rows required")
    for i,r in enumerate(rows):
        if not isinstance(r, dict): raise IntegratedModelError(f"row {i} is not an object")
        for k in ("timestamp_utc","demand_index","pv_capacity_factor","wind_onshore_capacity_factor","temperature_C","thermal_demand_index","day_ahead_price_EUR_MWh_synthetic"):
            if k not in r: raise IntegratedModelError(f"row {i} missing {k}")
        for k in ("demand_index","pv_capacity_factor","wind_onshore_capacity_factor","thermal_demand_index","day_ahead_price_EUR_MWh_synthetic"):
            _num(r[k], f"rows[{i}].{k}")
        if not 0 <= float(r["pv_capacity_factor"]) <= 1 or not 0 <= float(r["wind_onshore_capacity_factor"]) <= 1:
            raise IntegratedModelError(f"row {i} capacity factor outside [0,1]")
    regions = data["working_model_assumptions"]["regions"]
    if not regions or abs(sum(float(x["annual_demand_share"]) for x in regions.values()) - 1) > 1e-9:
        raise IntegratedModelError("regional demand shares must sum to 1")
    return data, _sha(p)

@dataclass(frozen=True)
class IntegratedOptions:
    scenario_id: str = "reference"
    stress_id: str | None = None
    heat_pump_share: float = 0.40
    ev_share_of_transport: float = 0.80
    flexible_fraction: float = 0.08
    hydrogen_surplus_fraction: float = 0.15
    hydrogen_storage_kg: float = 500_000.0
    hydrogen_reconversion_mw: float = 2_000.0
    national_import_limit_mw: float = 30_000.0
    reserve_fraction_of_demand: float = 0.10
    grid_ramp_limit_mw: float = 10_000.0
    hours_limit: int | None = None

@dataclass
class _State:
    battery_mwh: float = 0.0
    battery_throughput_mwh: float = 0.0
    pumped_mwh: float = 0.0
    hydrogen_kg: float = 0.0
    hot_water_mwh: float = 0.0

def _scenario(data, scenario_id):
    for s in data["scenario_catalog"]["scenarios"]:
        if s["id"] == scenario_id: return s
    raise IntegratedModelError(f"unknown scenario_id: {scenario_id}")

def _stress(data, stress_id):
    if stress_id is None: return None
    for e in data["stress_event_library"]["events"]:
        if e["id"] == stress_id: return e
    raise IntegratedModelError(f"unknown stress_id: {stress_id}")

def simulate_integrated(data: dict[str, Any], options: IntegratedOptions = IntegratedOptions()) -> dict[str, Any]:
    """Run a transparent regional transport/dispatch simulation over supplied hourly rows.

    Regional links are aggregated transport capacities, not AC power-flow constraints.
    Hydrogen is produced from otherwise-curtailed renewable energy and can reconvert
    during deficits. Flexible demand is shifted only within the current hour in this
    first increment; multi-hour optimization is deliberately a later step.
    """
    if not 0 < options.heat_pump_share <= 1 or not 0 <= options.ev_share_of_transport <= 1 or not 0 <= options.flexible_fraction <= 1 or not 0 <= options.reserve_fraction_of_demand <= 1 or options.grid_ramp_limit_mw < 0:
        raise IntegratedModelError("shares must be within their documented bounds")
    sc, stress = _scenario(data, options.scenario_id), _stress(data, options.stress_id)
    assumptions = data["working_model_assumptions"]; base = data["user_supplied_reference_parameter_baseline"]
    rows = data["synthetic_hourly_profiles_2025"]["rows"]
    n = len(rows) if options.hours_limit is None else min(len(rows), int(options.hours_limit))
    if n < 1: raise IntegratedModelError("hours_limit must leave at least one row")
    regions = assumptions["regions"]
    links = assumptions["network_defaults"]["interregional_links"]
    scenario = sc
    stress_duration = int(stress["duration_hours"]) if stress else 0
    states = {r: _State() for r in regions}
    annual_electric_mwh = float(base["electricity"]["gross_consumption_TWh"]) * 1_000_000
    annual_heat_mwh = float(base["heat"]["building_heat_demand_TWh"]) * 1_000_000
    annual_ev_mwh = float(base["electricity"]["sector_consumption_TWh"]["transport"]) * 1_000_000 * options.ev_share_of_transport
    demand_index_sum = sum(float(r["demand_index"]) for r in rows)
    thermal_index_sum = sum(float(r["thermal_demand_index"]) for r in rows)
    # Default technology powers are explicit working assumptions, derived from regional capacities.
    tech = assumptions["storage_technology_defaults"]
    batt = tech["battery_LFP"]; h2 = tech["hydrogen_chain"]
    totals = {k: 0.0 for k in ("demand_mwh","heat_demand_mwh_th","ev_mwh","renewable_mwh","served_mwh","unserved_mwh","heat_served_mwh_th","heat_unserved_mwh_th","curtailment_mwh","h2_produced_kg","h2_storage_loss_kg","h2_reconversion_mwh","grid_import_mwh","interregional_exchange_mwh","interregional_loss_mwh","flex_shift_mwh","battery_charge_mwh","battery_discharge_mwh","battery_degradation_mwh","co2_kg","operating_cost_eur","capex_proxy_eur","reserve_shortfall_mwh")}
    hourly=[]
    previous_unserved=False; loss_events=0; previous_grid = options.national_import_limit_mw
    for i, r in enumerate(rows[:n]):
        active_stress = bool(stress and i < stress_duration)
        dmul = float(scenario["demand_multiplier"]) * (float(stress.get("demand_multiplier", 1.0)) if active_stress else 1.0)
        pv_stress = (stress.get("pv_capacity_factor_override", stress.get("pv_capacity_factor_multiplier", 1.0)) if active_stress else 1.0)
        wind_stress = (stress.get("wind_capacity_factor_override", stress.get("wind_capacity_factor_multiplier", 1.0)) if active_stress else 1.0)
        pmul = float(scenario["pv_multiplier"]) * float(pv_stress)
        wmul = float(scenario["wind_multiplier"]) * float(wind_stress)
        grid_av = float(stress.get("grid_availability_fraction", 1.0)) if active_stress else 1.0
        national_demand = annual_electric_mwh * float(r["demand_index"]) / demand_index_sum * dmul
        heat_demand = annual_heat_mwh * float(r["thermal_demand_index"]) / thermal_index_sum * dmul
        ev = annual_ev_mwh * float(r["demand_index"]) / demand_index_sum * dmul if annual_ev_mwh else 0.0
        flex = national_demand * options.flexible_fraction
        hp_electric = heat_demand * options.heat_pump_share / max(1.0, float(base["heat"]["heat_pump_COP"]["real_world_seasonal_performance_factor"][0]))
        total_demand = national_demand + ev + hp_electric
        renewable = 0.0; local_surplus = 0.0; regional = {}
        for rid, cfg in regions.items():
            share = float(cfg["annual_demand_share"])
            demand = total_demand * share
            pv = float(cfg["pv_capacity_GW"]) * 1000 * float(r["pv_capacity_factor"]) * pmul
            wind = (float(cfg["wind_onshore_capacity_GW"]) + float(cfg["wind_offshore_capacity_GW"])) * 1000 * float(r["wind_onshore_capacity_factor"]) * wmul
            gen = pv + wind; renewable += gen
            regional[rid] = {"demand": demand, "generation": gen, "surplus": gen-demand, "served": 0.0, "unserved": 0.0}
        # Regional batteries absorb surplus and cover local deficits before transport.
        for rid, x in regional.items():
            st = states[rid]; bcap = max(0.0, sum(float(v.get("pv_capacity_GW",0)) for v in regions.values()) * 1000 * 0.02)
            self_loss = st.battery_mwh * (float(batt["self_discharge_fraction_per_day"]) / 24.0)
            st.battery_mwh = max(0.0, st.battery_mwh - self_loss)
            degradation = min(0.20, st.battery_throughput_mwh / max(1.0, 2.0 * float(batt["cycle_life_at_80pct_DOD"]) * bcap))
            effective_bcap = bcap * (1.0 - degradation)
            bpower = max(0.0, bcap / 4)
            if x["surplus"] > 0 and bcap:
                charge = min(x["surplus"], bpower, max(0.0, effective_bcap-st.battery_mwh)/float(batt["charge_efficiency"])); st.battery_mwh += charge*float(batt["charge_efficiency"]); st.battery_throughput_mwh += charge; x["surplus"] -= charge; totals["battery_charge_mwh"] += charge
            elif x["surplus"] < 0 and bcap:
                discharge = min(-x["surplus"], bpower, st.battery_mwh*float(batt["discharge_efficiency"])); st.battery_mwh -= discharge/float(batt["discharge_efficiency"]); st.battery_throughput_mwh += discharge; x["surplus"] += discharge; totals["battery_discharge_mwh"] += discharge
            totals["battery_degradation_mwh"] += bcap * degradation
            x["served"] = min(x["demand"], x["generation"] + max(0.0, x["demand"]-x["generation"]))
        # Directed transport on the supplied aggregate links; this is still not an AC flow solver.
        available_surplus = sum(max(0.0, x["surplus"]) for x in regional.values())
        link_multiplier = float(stress.get("interconnector_capacity_multiplier", 1.0)) if active_stress else 1.0
        link_flows = []
        exchange = 0.0; interconnector_loss = 0.0
        for link in links:
            src, dst = link["from"], link["to"]
            if src not in regional or dst not in regional: raise IntegratedModelError(f"network link references unknown region: {src}->{dst}")
            loss = _num(link["loss_fraction"], f"network link {src}->{dst} loss_fraction")
            if not 0 <= loss < 1: raise IntegratedModelError(f"network link {src}->{dst} loss_fraction outside [0,1)")
            sendable = max(0.0, regional[src]["surplus"])
            receivable = max(0.0, -regional[dst]["surplus"]) / max(1e-12, 1-loss)
            flow = min(sendable, receivable, float(link["capacity_MW"]) * link_multiplier)
            if flow > 0:
                delivered = flow * (1-loss)
                regional[src]["surplus"] -= flow; regional[dst]["surplus"] += delivered
                exchange += delivered; interconnector_loss += flow-delivered
                link_flows.append({"from":src,"to":dst,"sent_mwh":flow,"delivered_mwh":delivered,"loss_mwh":flow-delivered,"capacity_mw":float(link["capacity_MW"]) * link_multiplier})
        remaining_surplus = sum(max(0.0, x["surplus"]) for x in regional.values())
        remaining_deficit = sum(max(0.0, -x["surplus"]) for x in regional.values())
        # Hydrogen from surplus, then reconversion, external import, finally unserved energy.
        h2_energy = 0.0; h2_prod = 0.0; reconv = 0.0; grid = 0.0
        h2_eff = float(h2["electrolyzer_efficiency_LHV"]); reconv_eff = float(h2["reconversion_efficiency_LHV"])
        h2_surplus = remaining_surplus * options.hydrogen_surplus_fraction
        h2_prod = min(options.hydrogen_storage_kg-states[next(iter(states))].hydrogen_kg, h2_surplus*1000*h2_eff/33.33)
        # Shared H2 store proxy; retained as a transparent national state.
        national_h2 = states[next(iter(states))]
        h2_loss = national_h2.hydrogen_kg * (float(h2["storage_loss_fraction_per_day"]) / 24.0)
        national_h2.hydrogen_kg = max(0.0, national_h2.hydrogen_kg - h2_loss)
        totals["h2_storage_loss_kg"] += h2_loss
        national_h2.hydrogen_kg += max(0.0,h2_prod); h2_energy = national_h2.hydrogen_kg*33.33*reconv_eff/1000
        reconv = min(remaining_deficit, h2_energy, options.hydrogen_reconversion_mw); national_h2.hydrogen_kg -= reconv*1000/(33.33*reconv_eff)
        remaining_deficit -= reconv
        grid_cap = options.national_import_limit_mw * grid_av
        grid = min(remaining_deficit, grid_cap, previous_grid + options.grid_ramp_limit_mw)
        previous_grid = grid
        unserved = max(0.0, remaining_deficit-grid)
        reserve_requirement = total_demand * options.reserve_fraction_of_demand
        reserve_available = max(0.0, options.national_import_limit_mw*grid_av-grid) + max(0.0, options.hydrogen_reconversion_mw-reconv)
        reserve_shortfall = max(0.0, reserve_requirement-reserve_available)
        served = total_demand-unserved; heat_served = min(heat_demand, heat_demand*options.heat_pump_share) if served >= total_demand else min(heat_demand, max(0.0, served-national_demand-ev)*max(1.0,float(base["heat"]["heat_pump_COP"]["real_world_seasonal_performance_factor"][0])))
        heat_unserved = max(0.0, heat_demand-heat_served)
        price = float(r["day_ahead_price_EUR_MWh_synthetic"]) * float(scenario["grid_price_multiplier"])
        co2 = grid * float(base["costs_and_emissions"]["grid_emissions_gCO2_per_kWh"]["2025"])
        cost = grid*price + unserved*float(assumptions["flexibility_defaults"]["unserved_electricity_cost_EUR_per_MWh"])
        if unserved > 0 and not previous_unserved: loss_events += 1
        previous_unserved = unserved > 0
        for k,v in (("demand_mwh",total_demand),("heat_demand_mwh_th",heat_demand),("ev_mwh",ev),("renewable_mwh",renewable),("served_mwh",served),("unserved_mwh",unserved),("heat_served_mwh_th",heat_served),("heat_unserved_mwh_th",heat_unserved),("curtailment_mwh",max(0.0,remaining_surplus-h2_surplus)),("h2_produced_kg",h2_prod),("h2_reconversion_mwh",reconv),("grid_import_mwh",grid),("interregional_exchange_mwh",exchange),("interregional_loss_mwh",interconnector_loss),("flex_shift_mwh",flex),("reserve_shortfall_mwh",reserve_shortfall),("co2_kg",co2),("operating_cost_eur",cost)): totals[k] += v
        hourly.append({"timestamp_utc":r["timestamp_utc"],"demand_mwh":total_demand,"base_demand_mwh":national_demand,"heat_demand_mwh_th":heat_demand,"ev_mwh":ev,"renewable_mwh":renewable,"served_mwh":served,"unserved_mwh":unserved,"heat_served_mwh_th":heat_served,"heat_unserved_mwh_th":heat_unserved,"interregional_exchange_mwh":exchange,"interregional_loss_mwh":interconnector_loss,"interregional_flows":link_flows,"grid_import_mwh":grid,"grid_ramp_limit_mw":options.grid_ramp_limit_mw,"h2_produced_kg":h2_prod,"h2_storage_loss_kg":h2_loss,"h2_reconversion_mwh":reconv,"reserve_requirement_mw":reserve_requirement,"reserve_available_mw":reserve_available,"reserve_shortfall_mw":reserve_shortfall,"curtailment_mwh":max(0.0,remaining_surplus-h2_surplus),"synthetic_price_eur_per_mwh":price,"co2_kg":co2,"stress_active":active_stress})
    totals["capex_proxy_eur"] = (sum(float(v["pv_capacity_GW"]+v["wind_onshore_capacity_GW"]+v["wind_offshore_capacity_GW"]) for v in regions.values()) * 1000 * float(batt["capex_EUR_per_kWh_energy"]))
    max_hourly_demand_error = max((abs(x["demand_mwh"] - x["served_mwh"] - x["unserved_mwh"]) for x in hourly), default=0.0)
    hourly_demand_sum_error = abs(sum(x["demand_mwh"] for x in hourly) - totals["demand_mwh"])
    return {"schema":"energy-lighthouse-integrated-run/v1","model_version":INTEGRATED_VERSION,"scenario_id":options.scenario_id,"stress_id":options.stress_id,"intervals":n,"data_evidence":{"dataset_status":data["metadata"].get("note"),"source_roles":["REFERENCE_PARAMETERS_USER_SUPPLIED","ILLUSTRATIVE_WORKING_ASSUMPTIONS","SYNTHETIC_TEST_DATA"],"not_a_certification":True},"totals":totals,"reliability":{"loss_of_load_hours":sum(1 for x in hourly if x["unserved_mwh"]>1e-9),"loss_of_load_events":loss_events,"service_fraction":totals["served_mwh"]/totals["demand_mwh"] if totals["demand_mwh"] else 1.0,"heat_service_fraction":totals["heat_served_mwh_th"]/totals["heat_demand_mwh_th"] if totals["heat_demand_mwh_th"] else 1.0,"reserve_shortfall_hours":sum(1 for x in hourly if x["reserve_shortfall_mw"]>1e-9),"minimum_reserve_available_mw":min((x["reserve_available_mw"] for x in hourly), default=0.0)},"checks":{"max_hourly_demand_balance_error_mwh":max_hourly_demand_error,"hourly_demand_sum_error_mwh":hourly_demand_sum_error,"demand_balance_pass":max_hourly_demand_error < 1e-6 and hourly_demand_sum_error < 1e-5},"limitations":["aggregated interregional transport, no AC/DC power flow or N-1","reserve is a static headroom proxy, not frequency/ramp/contingency analysis","deterministic greedy dispatch, no LP/MILP optimum","synthetic hourly profiles and illustrative assumptions are not empirical","hydrogen and EV defaults are transparent working assumptions requiring domain review"],"hourly":hourly}

def run_catalog(data: dict[str, Any], *, include_stresses: bool = True, hours_limit: int | None = None) -> dict[str, Any]:
    """Evaluate the supplied scenario and stress catalogs without probabilities."""
    scenarios = [x["id"] for x in data["scenario_catalog"]["scenarios"]]
    stresses = [None] + [x["id"] for x in data["stress_event_library"]["events"]] if include_stresses else [None]
    if len(scenarios) * len(stresses) > 100: raise IntegratedModelError("catalog matrix exceeds 100 deterministic cases")
    cases = []
    for scenario_id in scenarios:
        for stress_id in stresses:
            r = simulate_integrated(data, IntegratedOptions(scenario_id=scenario_id, stress_id=stress_id, hours_limit=hours_limit))
            t, rel = r["totals"], r["reliability"]
            cases.append({"case_id": scenario_id + ("/" + stress_id if stress_id else "/baseline"), "scenario_id": scenario_id, "stress_id": stress_id, "intervals": r["intervals"], "service_fraction": rel["service_fraction"], "heat_service_fraction": rel["heat_service_fraction"], "unserved_mwh": t["unserved_mwh"], "heat_unserved_mwh_th": t["heat_unserved_mwh_th"], "grid_import_mwh": t["grid_import_mwh"], "h2_produced_kg": t["h2_produced_kg"], "co2_kg": t["co2_kg"], "operating_cost_eur": t["operating_cost_eur"]})
    return {"schema":"energy-lighthouse-integrated-catalog/v1","model_version":INTEGRATED_VERSION,"method":"deterministic full catalog enumeration; no probabilities","cases_tested":len(cases),"worst_service_case":min(cases,key=lambda x:(x["service_fraction"],-x["unserved_mwh"])),"lowest_co2_case":min(cases,key=lambda x:x["co2_kg"]),"lowest_operating_cost_case":min(cases,key=lambda x:x["operating_cost_eur"]),"cases":cases,"not_a_certification":True}

def run_design_sweep(data: dict[str, Any], *, scenario_id: str, stress_id: str | None = None,
                     heat_pump_shares=(0.30, 0.40, 0.50), flexible_fractions=(0.04, 0.08, 0.12),
                     hydrogen_storage_kg=(250_000.0, 500_000.0, 1_000_000.0),
                     import_limits_mw=(20_000.0, 30_000.0), hours_limit: int | None = None) -> dict[str, Any]:
    """Enumerate a bounded design grid; results are comparative, not globally optimal."""
    dimensions = (tuple(heat_pump_shares), tuple(flexible_fractions), tuple(hydrogen_storage_kg), tuple(import_limits_mw))
    count = math.prod(len(x) for x in dimensions)
    if count < 1 or count > 200: raise IntegratedModelError("design sweep must contain 1..200 cases")
    cases = []
    for hp in dimensions[0]:
        for flex in dimensions[1]:
            for h2cap in dimensions[2]:
                for imp in dimensions[3]:
                    opts = IntegratedOptions(scenario_id=scenario_id, stress_id=stress_id, heat_pump_share=float(hp), flexible_fraction=float(flex), hydrogen_storage_kg=float(h2cap), national_import_limit_mw=float(imp), hours_limit=hours_limit)
                    r = simulate_integrated(data, opts); t, rel = r["totals"], r["reliability"]
                    cases.append({"case_id":f"HP{float(hp):g}_F{float(flex):g}_H2{float(h2cap):g}_I{float(imp):g}","heat_pump_share":float(hp),"flexible_fraction":float(flex),"hydrogen_storage_kg":float(h2cap),"import_limit_mw":float(imp),"service_fraction":rel["service_fraction"],"heat_service_fraction":rel["heat_service_fraction"],"unserved_mwh":t["unserved_mwh"],"heat_unserved_mwh_th":t["heat_unserved_mwh_th"],"operating_cost_eur":t["operating_cost_eur"],"co2_kg":t["co2_kg"],"h2_produced_kg":t["h2_produced_kg"],"demand_balance_pass":r["checks"]["demand_balance_pass"]})
    pareto = [c for c in cases if not any(all(o[k] <= c[k] for k in ("operating_cost_eur","unserved_mwh","heat_unserved_mwh_th","co2_kg")) and any(o[k] < c[k] for k in ("operating_cost_eur","unserved_mwh","heat_unserved_mwh_th","co2_kg")) for o in cases)]
    return {"schema":"energy-lighthouse-design-sweep/v1","model_version":INTEGRATED_VERSION,"method":"bounded complete enumeration of supplied design grid; no continuous/global optimum","scenario_id":scenario_id,"stress_id":stress_id,"cases_tested":len(cases),"pareto_front_count":len(pareto),"pareto_front":pareto,"best_service_case":max(cases,key=lambda x:(x["service_fraction"],-x["operating_cost_eur"])),"lowest_cost_case":min(cases,key=lambda x:x["operating_cost_eur"]),"lowest_co2_case":min(cases,key=lambda x:x["co2_kg"]),"cases":cases,"not_a_certification":True}
