from __future__ import annotations
import argparse
from dataclasses import replace
from pathlib import Path
from datetime import datetime, timezone
from .io import load_scenario, write_simulation, write_json, write_input_snapshot, import_timeseries_csv, write_sensitivity
from .model import VERSION, simulate, sweep_battery, run_sensitivity
from .integrated import IntegratedOptions, load_working_data, simulate_integrated, run_catalog, run_design_sweep, INTEGRATED_VERSION

STRESSES = ("baseline", "grid-outage", "generator-outage", "pv-outage", "wind-outage", "demand-plus-10")

def parse_values(text: str) -> list[float]:
    try:
        values = [float(x.strip()) for x in text.split(",") if x.strip()]
    except ValueError as e:
        raise argparse.ArgumentTypeError("use comma-separated finite numbers") from e
    if not values:
        raise argparse.ArgumentTypeError("list cannot be empty")
    return values

def stressed(s, case):
    if case == "grid-outage":
        return replace(s, name=f"{s.name} / {case}", grid=replace(s.grid, max_import_mw=0, availability=0))
    if case == "generator-outage":
        return replace(s, name=f"{s.name} / {case}", generator=replace(s.generator, capacity_mw=0, availability=0))
    if case == "pv-outage":
        return replace(s, name=f"{s.name} / {case}", pv_mw=tuple(0.0 for _ in s.pv_mw))
    if case == "wind-outage":
        return replace(s, name=f"{s.name} / {case}", wind_mw=tuple(0.0 for _ in s.wind_mw))
    if case == "demand-plus-10":
        return replace(s, name=f"{s.name} / {case}", demand_mw=tuple(v * 1.10 for v in s.demand_mw))
    return s

def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="energy-lighthouse", description="Lokaler, vereinfachter Energiesystem-Rechenkern")
    parser.add_argument("--version", action="version", version=f"energy-lighthouse {VERSION}")
    sub = parser.add_subparsers(dest="command", required=True)
    imp = sub.add_parser("import-csv", help="validierte CSV-Zeitreihe in ein Szenario-JSON konvertieren")
    imp.add_argument("profile"); imp.add_argument("--out", default="runs/imported-scenario.json")
    imp.add_argument("--name", default=None); imp.add_argument("--interval-hours", type=float, default=1.0)
    sim = sub.add_parser("simulate", help="stündliche Strom-/Wärmebilanz berechnen")
    sim.add_argument("scenario"); sim.add_argument("--out", default="runs/reference")
    sim.add_argument("--stress", choices=STRESSES, default="baseline")
    sw = sub.add_parser("sweep", help="diskrete Batterie-Kandidaten und Paretofront vergleichen")
    sw.add_argument("scenario"); sw.add_argument("--capacities", type=parse_values, default=parse_values("0,2,4,8,12"))
    sw.add_argument("--powers", type=parse_values, default=parse_values("0,1,2,4")); sw.add_argument("--out", default="runs/sweep")
    st = sub.add_parser("stress", help="sechs deterministische Ausfall-/Lastfälle vergleichen")
    st.add_argument("scenario"); st.add_argument("--out", default="runs/stress")
    se = sub.add_parser("sensitivity", help="deterministische Nachfrage-/Erneuerbaren-/Netzpreis-Sensitivität")
    se.add_argument("scenario"); se.add_argument("--demand-scales", type=parse_values, default=parse_values("0.9,1.0,1.1"))
    se.add_argument("--renewable-scales", type=parse_values, default=parse_values("0.8,1.0,1.2"))
    se.add_argument("--grid-price-scales", type=parse_values, default=parse_values("0.8,1.0,1.2")); se.add_argument("--out", default="runs/sensitivity")
    integ = sub.add_parser("integrated", help="regionale, sektorübergreifende Simulation aus dem Arbeitsdatensatz")
    integ.add_argument("dataset", help="energy_lighthouse_working_data_0.1.json")
    integ.add_argument("--scenario-id", default="reference")
    integ.add_argument("--stress-id", default=None)
    integ.add_argument("--out", default="runs/integrated")
    integ.add_argument("--hours", type=int, default=None, help="optionaler begrenzter Lauf für Entwicklungstests")
    cat = sub.add_parser("catalog", help="alle gelieferten Szenarien und Stressereignisse deterministisch vergleichen")
    cat.add_argument("dataset")
    cat.add_argument("--out", default="runs/integrated-catalog")
    cat.add_argument("--hours", type=int, default=None)
    ds = sub.add_parser("design-sweep", help="begrenztes Designraster für Flexibilität, H2, Import und Wärmepumpen")
    ds.add_argument("dataset")
    ds.add_argument("--scenario-id", default="baseline_2026")
    ds.add_argument("--stress-id", default=None)
    ds.add_argument("--out", default="runs/integrated-design-sweep")
    ds.add_argument("--hours", type=int, default=None)
    args = parser.parse_args(argv)
    if args.command == "import-csv":
        result = import_timeseries_csv(args.profile, args.out, args.name or Path(args.profile).stem, args.interval_hours)
        print(f"OK: {result['output']} ({result['intervals']} Intervalle; Zeitstempel geprüft: {result['timestamps_checked']}; Wärmelast importiert: {result['thermal_profile_imported']})")
        return 0
    if args.command == "integrated":
        data, digest = load_working_data(args.dataset)
        result = simulate_integrated(data, IntegratedOptions(scenario_id=args.scenario_id, stress_id=args.stress_id, hours_limit=args.hours))
        out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
        write_input_snapshot(args.dataset, out, digest)
        write_json({"schema": "energy-lighthouse-integrated-envelope/v1", "software_version": VERSION, "integrated_model_version": INTEGRATED_VERSION, "source_file": Path(args.dataset).name, "source_sha256": digest, "not_a_certification": True, "result": {k:v for k,v in result.items() if k != "hourly"}}, out / "report.json")
        write_json(result, out / "result.json")
        if result["hourly"]:
            import csv
            with (out / "hourly.csv").open("w", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=list(result["hourly"][0])); w.writeheader(); w.writerows(result["hourly"])
        print(f"OK: {out} ({result['intervals']} Stunden; Versorgung {result['reliability']['service_fraction']:.2%}; nicht zertifiziert)")
        return 0
    if args.command == "catalog":
        data, digest = load_working_data(args.dataset)
        result = run_catalog(data, hours_limit=args.hours)
        out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
        write_input_snapshot(args.dataset, out, digest)
        write_json({"schema": "energy-lighthouse-integrated-catalog-envelope/v1", "software_version": VERSION, "integrated_model_version": INTEGRATED_VERSION, "source_file": Path(args.dataset).name, "source_sha256": digest, "result": result}, out / "catalog.json")
        print(f"OK: {out}/catalog.json ({result['cases_tested']} deterministische Fälle; keine Wahrscheinlichkeiten)")
        return 0
    if args.command == "design-sweep":
        data, digest = load_working_data(args.dataset)
        result = run_design_sweep(data, scenario_id=args.scenario_id, stress_id=args.stress_id, hours_limit=args.hours)
        out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
        write_input_snapshot(args.dataset, out, digest)
        write_json({"schema": "energy-lighthouse-design-sweep-envelope/v1", "software_version": VERSION, "integrated_model_version": INTEGRATED_VERSION, "source_file": Path(args.dataset).name, "source_sha256": digest, "result": result}, out / "design-sweep.json")
        print(f"OK: {out}/design-sweep.json ({result['cases_tested']} Fälle; Pareto {result['pareto_front_count']}; keine globale Optimierung)")
        return 0
    scenario, digest = load_scenario(args.scenario)
    if args.command == "simulate":
        result = simulate(stressed(scenario, args.stress))
        write_simulation(result, args.out, args.scenario, digest)
        print(f"OK: {args.out} (Stromversorgung {result['totals']['service_fraction']:.2%}; Wärmedeckung {result['totals']['heat_service_fraction']:.2%}; Bilanz {'PASS' if result['checks']['energy_balance_pass'] else 'FAIL'})")
    elif args.command == "sweep":
        result = sweep_battery(scenario, args.capacities, args.powers)
        out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
        snapshot = write_input_snapshot(args.scenario, out, digest)
        payload = {"schema": "energy-lighthouse-sweep/v1", "created_utc": datetime.now(timezone.utc).isoformat(), "software_version": VERSION, "source_file": Path(args.scenario).name, "source_sha256": digest, "reproduction_input": snapshot, "evidence_status": "user assumptions, not independently verified", "result": result}
        write_json(payload, out / "sweep.json")
        best = result["best_tested_by_cost"]
        print(f"OK: {out}; {result['candidates_tested']} Kandidaten; Pareto-Punkte {result['pareto_front_count']}; Kostenbestpunkt {best['capacity_mwh']} MWh/{best['power_mw']} MW")
    elif args.command == "sensitivity":
        result = run_sensitivity(scenario, args.demand_scales, args.renewable_scales, args.grid_price_scales)
        write_sensitivity(result, args.out, args.scenario, digest)
        print(f"OK: {args.out}/sensitivity.json ({result['cases_tested']} deterministische Fälle; keine Wahrscheinlichkeiten)")
    else:
        cases = []
        for name in STRESSES:
            r = simulate(stressed(scenario, name))
            t = r["totals"]
            cases.append({"case": name, "service_fraction": t["service_fraction"], "unserved_mwh": t["unserved_mwh"], "loss_of_load_hours": t["loss_of_load_hours"], "heat_unserved_mwh_th": t["heat_unserved_mwh_th"], "generator_output_mwh": t["generator_output_mwh"], "reserve_shortfall_mw_hours": t["reserve_shortfall_mw_hours"], "system_emissions_kg": t["system_emissions_kg"], "energy_balance_pass": r["checks"]["energy_balance_pass"]})
        out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
        snapshot = write_input_snapshot(args.scenario, out, digest)
        payload = {"schema": "energy-lighthouse-stress/v1", "created_utc": datetime.now(timezone.utc).isoformat(), "software_version": VERSION, "source_file": Path(args.scenario).name, "source_sha256": digest, "reproduction_input": snapshot, "interpretation": "deterministic contingencies; no event probabilities or grid stability model", "cases": cases}
        write_json(payload, out / "stress.json")
        print(f"OK: {args.out}/stress.json ({len(cases)} Fälle)")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
