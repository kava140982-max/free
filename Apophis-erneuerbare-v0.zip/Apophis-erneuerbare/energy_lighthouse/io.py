"""Strict JSON/CSV input handling and reproducible report export."""
from __future__ import annotations
import csv, hashlib, io, json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from .model import Battery, DispatchableGenerator, Grid, HeatPump, ModelError, Scenario, VERSION

MAX_INPUT_BYTES = 1_000_000
MAX_CSV_BYTES = 2_000_000

def _unique_object(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError(f"duplicate JSON key: {key}")
        obj[key] = value
    return obj

def load_scenario(path: str | Path) -> tuple[Scenario, str]:
    p = Path(path)
    raw = p.read_bytes()
    if len(raw) > MAX_INPUT_BYTES:
        raise ValueError("scenario JSON exceeds 1 MB safety limit")
    data = json.loads(raw.decode("utf-8"), object_pairs_hook=_unique_object)
    if not isinstance(data, dict):
        raise ValueError("scenario root must be a JSON object")
    allowed = {"name", "interval_hours", "demand_mw", "pv_mw", "wind_mw", "battery", "grid", "generator", "heat_pump", "thermal_demand_mw_th", "reserve_requirement_mw", "value_of_lost_load_eur_per_mwh", "provenance"}
    unknown = set(data) - allowed
    missing = {"name", "interval_hours", "demand_mw", "pv_mw", "wind_mw"} - set(data)
    if unknown or missing:
        raise ValueError(f"invalid scenario keys; unknown={sorted(unknown)}, missing={sorted(missing)}")
    def section(name, allowed_keys):
        value = data.get(name, {})
        if not isinstance(value, dict) or set(value) - allowed_keys:
            raise ValueError(f"{name} must be an object with only documented keys")
        return value
    bd = section("battery", {"capacity_mwh", "power_mw", "charge_efficiency", "discharge_efficiency", "self_discharge_per_hour", "initial_soc_mwh", "capex_eur_per_mwh", "power_capex_eur_per_mw", "lifetime_years", "discount_rate", "annual_opex_fraction"})
    gd = section("grid", {"max_import_mw", "loss_fraction", "cost_eur_per_mwh_source", "emissions_kg_per_mwh_source", "availability"})
    hd = section("generator", {"capacity_mw", "availability", "efficiency", "fuel_cost_eur_per_mwh_fuel", "variable_om_eur_per_mwh_electric", "emissions_kg_per_mwh_fuel", "capex_eur_per_mw", "lifetime_years", "discount_rate", "annual_opex_fraction"})
    hp = section("heat_pump", {"capacity_mw_th", "cop", "capex_eur_per_mw_th", "lifetime_years", "discount_rate", "annual_opex_fraction"})
    for field in ("demand_mw", "pv_mw", "wind_mw"):
        if not isinstance(data[field], list):
            raise ValueError(f"{field} must be a JSON array")
    if "thermal_demand_mw_th" in data and not isinstance(data["thermal_demand_mw_th"], list):
        raise ValueError("thermal_demand_mw_th must be a JSON array")
    gd = dict(gd)
    if isinstance(gd.get("availability"), list):
        gd["availability"] = tuple(gd["availability"])
    hd = dict(hd)
    if isinstance(hd.get("availability"), list):
        hd["availability"] = tuple(hd["availability"])
    thermal = tuple(data.get("thermal_demand_mw_th", []))
    s = Scenario(data["name"], data["interval_hours"], tuple(data["demand_mw"]), tuple(data["pv_mw"]), tuple(data["wind_mw"]), Battery(**bd), Grid(**gd), data.get("value_of_lost_load_eur_per_mwh", 10_000), data.get("provenance", "not provided; evidence status unknown"), DispatchableGenerator(**hd), HeatPump(**hp), thermal, data.get("reserve_requirement_mw", 0.0))
    s.validate()
    return s, hashlib.sha256(raw).hexdigest()

def import_timeseries_csv(csv_path: str | Path, json_path: str | Path, name: str, interval_hours: float) -> dict[str, Any]:
    """Convert strict electric/optional thermal MW profiles to validated scenario JSON."""
    source = Path(csv_path)
    raw = source.read_bytes()
    if len(raw) > MAX_CSV_BYTES:
        raise ValueError("profile CSV exceeds 2 MB safety limit")
    reader = csv.reader(io.StringIO(raw.decode("utf-8-sig"), newline=""))
    try:
        headers = next(reader)
    except StopIteration as e:
        raise ValueError("profile CSV is empty") from e
    if len(headers) != len(set(headers)):
        raise ValueError("profile CSV has duplicate column names")
    required = {"demand_mw", "pv_mw", "wind_mw"}
    allowed = required | {"timestamp", "thermal_demand_mw_th"}
    if not required.issubset(headers) or set(headers) - allowed:
        raise ValueError("CSV requires demand_mw,pv_mw,wind_mw with optional timestamp,thermal_demand_mw_th")
    index = {h: headers.index(h) for h in headers}
    keys = list(required) + (["thermal_demand_mw_th"] if "thermal_demand_mw_th" in index else [])
    values = {k: [] for k in keys}
    stamps = []
    for row_number, row in enumerate(reader, start=2):
        if not row:
            continue
        if len(row) != len(headers):
            raise ValueError(f"CSV row {row_number} has {len(row)} fields; expected {len(headers)}")
        try:
            for key in keys:
                values[key].append(float(row[index[key]].strip()))
        except (ValueError, AttributeError) as e:
            raise ValueError(f"CSV row {row_number} contains a non-numeric power value") from e
        if "timestamp" in index:
            try:
                stamp = datetime.fromisoformat(row[index["timestamp"]].strip().replace("Z", "+00:00"))
            except ValueError as e:
                raise ValueError(f"CSV row {row_number} has an invalid ISO-8601 timestamp") from e
            if stamp.tzinfo is None:
                raise ValueError(f"CSV row {row_number} timestamp must include a UTC offset")
            stamps.append(stamp)
        if len(values["demand_mw"]) > 8784:
            raise ValueError("CSV profile exceeds 8784 intervals")
    count = len(values["demand_mw"])
    if count == 0:
        raise ValueError("profile CSV contains no data rows")
    if stamps:
        if len(stamps) != count:
            raise ValueError("timestamps are missing from one or more profile rows")
        expected = float(interval_hours) * 3600
        for i, (a, b) in enumerate(zip(stamps, stamps[1:]), start=2):
            delta = (b - a).total_seconds()
            if delta <= 0 or abs(delta - expected) > 1:
                raise ValueError(f"timestamps are not strictly increasing at row {i} or do not match interval_hours")
    thermal = tuple(values.get("thermal_demand_mw_th", []))
    scenario = Scenario(name, interval_hours, tuple(values["demand_mw"]), tuple(values["pv_mw"]), tuple(values["wind_mw"]), Battery(), Grid(), provenance=f"CSV import from {source.name}; source_sha256={hashlib.sha256(raw).hexdigest()}", thermal_demand_mw_th=thermal)
    scenario.validate()
    payload = {"name": scenario.name, "interval_hours": scenario.interval_hours, "demand_mw": list(scenario.demand_mw), "pv_mw": list(scenario.pv_mw), "wind_mw": list(scenario.wind_mw), "battery": {}, "grid": {}, "generator": {}, "heat_pump": {}, "provenance": scenario.provenance}
    if thermal:
        payload["thermal_demand_mw_th"] = list(thermal)
    target = Path(json_path)
    if target.resolve() == source.resolve():
        raise ValueError("scenario output must not overwrite the input CSV")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    loaded, scenario_sha = load_scenario(target)
    if loaded.n != count:
        target.unlink(missing_ok=True)
        raise ModelError("CSV import output failed validation")
    return {"output": str(target), "intervals": count, "profile_sha256": hashlib.sha256(raw).hexdigest(), "scenario_sha256": scenario_sha, "timestamps_checked": bool(stamps), "thermal_profile_imported": bool(thermal)}

def write_input_snapshot(source_path: str | Path, output_dir: str | Path, expected_sha256: str) -> str:
    raw = Path(source_path).read_bytes()
    actual = hashlib.sha256(raw).hexdigest()
    if actual != expected_sha256:
        raise ValueError("scenario input changed after it was loaded; refusing a mismatched report")
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    (Path(output_dir) / "scenario.input.json").write_bytes(raw)
    return "scenario.input.json"

def write_simulation(result: dict[str, Any], output_dir: str | Path, source_path: str, source_sha256: str) -> None:
    out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    snapshot_name = write_input_snapshot(source_path, out, source_sha256)
    summary = {k: v for k, v in result.items() if k != "hourly"}
    report = {"schema": "energy-lighthouse-run/v1", "run": {"created_utc": datetime.now(timezone.utc).isoformat(), "software_version": VERSION, "source_file": Path(source_path).name, "source_sha256": source_sha256, "reproduction_input": snapshot_name, "evidence_status": "scenario provenance is user-supplied and not independently verified"}, "result": summary}
    (out / "report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8")
    rows = result["hourly"]
    if rows:
        with (out / "hourly.csv").open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    t, e = result["totals"], result["economics"]
    text = f'''# Energiebilanz: {result['scenario']}\n\n- Dispatch: {result['dispatch_method']}\n- Zeitreihe: {result['intervals']} × {result['interval_hours']} h\n- Basisstrom: {t['base_electric_demand_mwh']:.3f} MWh; tatsächlich verbraucht: {t['electricity_consumed_mwh']:.3f} MWh; ungedeckte Grundlast: {t['unserved_mwh']:.3f} MWh\n- Erneuerbare Erzeugung: {t['renewable_generation_mwh']:.3f} MWh; Abregelung: {t['renewable_curtailment_mwh']:.3f} MWh\n- Wärmelast: {t['heat_demand_mwh_th']:.3f} MWh_th; geliefert: {t['heat_delivered_mwh_th']:.3f} MWh_th; ungedeckt: {t['heat_unserved_mwh_th']:.3f} MWh_th; Wärmepumpenstrom: {t['heat_pump_electricity_consumed_mwh']:.3f} MWh\n- Generator: {t['generator_output_mwh']:.3f} MWh_el aus {t['generator_fuel_input_mwh']:.3f} MWh_fuel; Umwandlungsverlust: {t['generator_conversion_losses_mwh']:.3f} MWh\n- Netzbezug: {t['grid_delivered_mwh']:.3f} MWh; Leitungsverlust: {t['grid_transport_loss_mwh']:.3f} MWh; Systememissionen: {t['system_emissions_kg']:.1f} kg (angenommen)\n- Versorgung: {t['service_fraction']:.2%}; LOLE: {t['loss_of_load_hours']:.3f} h in {t['loss_of_load_events']} Ereignissen; Spitzenlastabwurf: {t['peak_unserved_mw']:.3f} MW\n- Reserveanforderung: {t['reserve_requirement_mw']:.3f} MW; Mindestreserve: {t['minimum_reserve_available_mw']:.3f} MW; Reservefehlstunden: {t['reserve_shortfall_hours']:.3f} h\n- Annualäquivalente Systemkosten: {e['annual_equivalent_total_cost_eur']:.2f} €; Bilanztest: {'BESTANDEN' if result['checks']['energy_balance_pass'] else 'FEHLER'} (max. Busfehler {result['checks']['max_hourly_bus_balance_abs_error_mwh']:.3g} MWh)\n\nJahreskosten unterstellen eine gleichförmige Wiederholung des Eingabeprofils, keine Jahressimulation. Parameter und Emissionsfaktoren sind Annahmen; keine Netzstabilitätsprüfung.\n\nDetails: `report.json`, `hourly.csv`; wiederholbare Eingabe: `scenario.input.json` (SHA-256 `{source_sha256}`). Hashes beweisen keine inhaltliche Richtigkeit.\n'''
    (out / "summary.md").write_text(text, encoding="utf-8")

def write_json(data: Any, path: str | Path) -> None:
    p = Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8")

def write_sensitivity(result: dict[str, Any], output_dir: str | Path, source_path: str, source_sha256: str) -> None:
    out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    snapshot = write_input_snapshot(source_path, out, source_sha256)
    envelope = {"schema": "energy-lighthouse-sensitivity/v1", "created_utc": datetime.now(timezone.utc).isoformat(), "software_version": VERSION, "source_file": Path(source_path).name, "source_sha256": source_sha256, "reproduction_input": snapshot, "evidence_status": "deterministic synthetic/user scenarios; no probabilities", "result": result}
    write_json(envelope, out / "sensitivity.json")
    rows = result["cases"]
    if rows:
        with (out / "sensitivity.csv").open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
