"""Transparent hourly energy-system model; standard-library only."""
from __future__ import annotations
from dataclasses import dataclass, replace
from math import isfinite
from typing import Any

VERSION = "0.3.0"

class ModelError(ValueError):
    pass

def _number(value: Any, name: str, minimum: float | None = None) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(float(value)):
        raise ModelError(f"{name} must be a finite number")
    out = float(value)
    if minimum is not None and out < minimum:
        raise ModelError(f"{name} must be >= {minimum}")
    return out

def _availability(value: Any, name: str, n: int) -> tuple[float, ...]:
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        x = _number(value, name)
        if not 0 <= x <= 1:
            raise ModelError(f"{name} must be in [0, 1]")
        return (x,) * n
    if not isinstance(value, (tuple, list)) or len(value) != n:
        raise ModelError(f"{name} must be a scalar or a time series with {n} values")
    result = tuple(_number(x, f"{name}[{i}]") for i, x in enumerate(value))
    if any(x < 0 or x > 1 for x in result):
        raise ModelError(f"{name} time series values must be in [0, 1]")
    return result

@dataclass(frozen=True)
class Battery:
    capacity_mwh: float = 0.0
    power_mw: float = 0.0
    charge_efficiency: float = 0.95
    discharge_efficiency: float = 0.95
    self_discharge_per_hour: float = 0.0001
    initial_soc_mwh: float = 0.0
    capex_eur_per_mwh: float = 180_000.0
    power_capex_eur_per_mw: float = 120_000.0
    lifetime_years: float = 15.0
    discount_rate: float = 0.05
    annual_opex_fraction: float = 0.02

@dataclass(frozen=True)
class Grid:
    max_import_mw: float = 20.0
    loss_fraction: float = 0.03
    cost_eur_per_mwh_source: float = 110.0
    emissions_kg_per_mwh_source: float = 250.0
    availability: float | tuple[float, ...] = 1.0

@dataclass(frozen=True)
class DispatchableGenerator:
    """Generic fuel-fired backup; fuel and emissions are explicit user assumptions."""
    capacity_mw: float = 0.0
    availability: float | tuple[float, ...] = 1.0
    efficiency: float = 0.40
    fuel_cost_eur_per_mwh_fuel: float = 80.0
    variable_om_eur_per_mwh_electric: float = 10.0
    emissions_kg_per_mwh_fuel: float = 202.0
    capex_eur_per_mw: float = 700_000.0
    lifetime_years: float = 25.0
    discount_rate: float = 0.05
    annual_opex_fraction: float = 0.04

@dataclass(frozen=True)
class HeatPump:
    capacity_mw_th: float = 0.0
    cop: float = 3.0
    capex_eur_per_mw_th: float = 0.0
    lifetime_years: float = 15.0
    discount_rate: float = 0.05
    annual_opex_fraction: float = 0.02

@dataclass(frozen=True)
class Scenario:
    name: str
    interval_hours: float
    demand_mw: tuple[float, ...]
    pv_mw: tuple[float, ...]
    wind_mw: tuple[float, ...]
    battery: Battery
    grid: Grid
    value_of_lost_load_eur_per_mwh: float = 10_000.0
    provenance: str = "user-supplied scenario; evidence status not independently verified"
    generator: DispatchableGenerator = DispatchableGenerator()
    heat_pump: HeatPump = HeatPump()
    thermal_demand_mw_th: tuple[float, ...] = ()
    reserve_requirement_mw: float = 0.0

    @property
    def n(self) -> int:
        return len(self.demand_mw)

    def validate(self) -> None:
        if not isinstance(self.name, str) or not self.name.strip() or len(self.name) > 120:
            raise ModelError("name must be a non-empty string of at most 120 characters")
        dt = _number(self.interval_hours, "interval_hours")
        if dt <= 0 or dt > 24:
            raise ModelError("interval_hours must be > 0 and <= 24")
        if not self.demand_mw or len(self.demand_mw) > 8784:
            raise ModelError("time series must contain 1..8784 intervals")
        if not (len(self.demand_mw) == len(self.pv_mw) == len(self.wind_mw)):
            raise ModelError("demand, pv, and wind series must have equal length")
        for label, series in (("demand_mw", self.demand_mw), ("pv_mw", self.pv_mw), ("wind_mw", self.wind_mw)):
            for i, val in enumerate(series):
                _number(val, f"{label}[{i}]", 0)
        if self.thermal_demand_mw_th and len(self.thermal_demand_mw_th) != self.n:
            raise ModelError("thermal_demand_mw_th must be empty or match the electric time series length")
        for i, val in enumerate(self.thermal_demand_mw_th):
            _number(val, f"thermal_demand_mw_th[{i}]", 0)
        _number(self.reserve_requirement_mw, "reserve_requirement_mw", 0)
        b = self.battery
        for field in ("capacity_mwh", "power_mw", "initial_soc_mwh", "capex_eur_per_mwh", "power_capex_eur_per_mw", "annual_opex_fraction"):
            _number(getattr(b, field), f"battery.{field}", 0)
        for field in ("charge_efficiency", "discharge_efficiency"):
            v = _number(getattr(b, field), f"battery.{field}")
            if not 0 < v <= 1:
                raise ModelError(f"battery.{field} must be in (0, 1]")
        loss = _number(b.self_discharge_per_hour, "battery.self_discharge_per_hour")
        if not 0 <= loss < 1:
            raise ModelError("battery.self_discharge_per_hour must be in [0, 1)")
        if _number(b.lifetime_years, "battery.lifetime_years") <= 0:
            raise ModelError("battery.lifetime_years must be > 0")
        if not 0 <= _number(b.discount_rate, "battery.discount_rate") <= 1:
            raise ModelError("battery.discount_rate must be in [0, 1]")
        if b.initial_soc_mwh > b.capacity_mwh:
            raise ModelError("battery.initial_soc_mwh cannot exceed capacity")
        g = self.grid
        _number(g.max_import_mw, "grid.max_import_mw", 0)
        if not 0 <= _number(g.loss_fraction, "grid.loss_fraction") < 1:
            raise ModelError("grid.loss_fraction must be in [0, 1)")
        _number(g.cost_eur_per_mwh_source, "grid.cost_eur_per_mwh_source", 0)
        _number(g.emissions_kg_per_mwh_source, "grid.emissions_kg_per_mwh_source", 0)
        _availability(g.availability, "grid.availability", self.n)
        _number(self.value_of_lost_load_eur_per_mwh, "value_of_lost_load_eur_per_mwh", 0)
        h = self.generator
        _number(h.capacity_mw, "generator.capacity_mw", 0)
        _availability(h.availability, "generator.availability", self.n)
        if not 0 < _number(h.efficiency, "generator.efficiency") <= 1:
            raise ModelError("generator.efficiency must be in (0, 1]")
        for field in ("fuel_cost_eur_per_mwh_fuel", "variable_om_eur_per_mwh_electric", "emissions_kg_per_mwh_fuel", "capex_eur_per_mw", "annual_opex_fraction"):
            _number(getattr(h, field), f"generator.{field}", 0)
        if _number(h.lifetime_years, "generator.lifetime_years") <= 0:
            raise ModelError("generator.lifetime_years must be > 0")
        if not 0 <= _number(h.discount_rate, "generator.discount_rate") <= 1:
            raise ModelError("generator.discount_rate must be in [0, 1]")
        hp = self.heat_pump
        _number(hp.capacity_mw_th, "heat_pump.capacity_mw_th", 0)
        if _number(hp.cop, "heat_pump.cop") < 1:
            raise ModelError("heat_pump.cop must be >= 1 for heating mode")
        _number(hp.capex_eur_per_mw_th, "heat_pump.capex_eur_per_mw_th", 0)
        if _number(hp.lifetime_years, "heat_pump.lifetime_years") <= 0:
            raise ModelError("heat_pump.lifetime_years must be > 0")
        if not 0 <= _number(hp.discount_rate, "heat_pump.discount_rate") <= 1:
            raise ModelError("heat_pump.discount_rate must be in [0, 1]")
        _number(hp.annual_opex_fraction, "heat_pump.annual_opex_fraction", 0)


def annuity_factor(rate: float, years: float) -> float:
    if years <= 0:
        raise ModelError("lifetime must be positive")
    if rate == 0:
        return 1.0 / years
    return rate * (1 + rate) ** years / ((1 + rate) ** years - 1)


def simulate(s: Scenario) -> dict[str, Any]:
    """Hourly heuristic; heat-pump demand is interruptible before base electric demand."""
    s.validate()
    b, g, h, hp, dt = s.battery, s.grid, s.generator, s.heat_pump, s.interval_hours
    grid_av = _availability(g.availability, "grid.availability", s.n)
    gen_av = _availability(h.availability, "generator.availability", s.n)
    soc = b.initial_soc_mwh
    rows: list[dict[str, float | int]] = []
    keys = ("base_demand", "electricity_consumed", "electricity_requested", "heat_demand", "heat_delivered", "heat_unserved", "hp_electricity", "renewable", "served", "unserved", "curtailment", "charge", "discharge", "generator", "fuel", "generator_loss", "grid_delivered", "grid_source", "grid_loss", "storage_loss", "grid_cost", "generator_cost", "unserved_cost", "grid_emissions", "generator_emissions", "loss_hours", "loss_events", "peak_unserved_mw", "reserve_available", "reserve_shortfall", "reserve_shortfall_hours")
    sums = {k: 0.0 for k in keys}
    max_bus_error = max_soc_error = 0.0
    loss_events = 0
    previously_unserved = False
    for i, (base_mw, pv_mw, wind_mw) in enumerate(zip(s.demand_mw, s.pv_mw, s.wind_mw)):
        base_demand = base_mw * dt
        heat_demand = (s.thermal_demand_mw_th[i] if s.thermal_demand_mw_th else 0.0) * dt
        heat_potential = min(heat_demand, hp.capacity_mw_th * dt)
        hp_electric_requested = heat_potential / hp.cop
        requested_electricity = base_demand + hp_electric_requested
        renewable = (pv_mw + wind_mw) * dt
        soc_start = soc
        self_loss = soc * (1 - (1 - b.self_discharge_per_hour) ** dt)
        soc -= self_loss
        net = renewable - requested_electricity
        charge_in = stored_charge = discharge = discharge_withdrawal = 0.0
        if net > 0 and b.capacity_mwh > 0 and b.power_mw > 0:
            charge_in = min(net, b.power_mw * dt, max(0.0, b.capacity_mwh - soc) / b.charge_efficiency)
            stored_charge = charge_in * b.charge_efficiency
            soc += stored_charge
        elif net < 0 and b.capacity_mwh > 0 and b.power_mw > 0:
            discharge = min(-net, b.power_mw * dt, soc * b.discharge_efficiency)
            discharge_withdrawal = discharge / b.discharge_efficiency
            soc -= discharge_withdrawal
        curtailment = max(0.0, net - charge_in)
        deficit = max(0.0, requested_electricity - renewable - discharge)
        generator_limit = h.capacity_mw * gen_av[i] * dt
        grid_limit_delivered = g.max_import_mw * grid_av[i] * dt * (1 - g.loss_fraction)
        gen_variable_cost = h.fuel_cost_eur_per_mwh_fuel / h.efficiency + h.variable_om_eur_per_mwh_electric
        grid_delivered_cost = g.cost_eur_per_mwh_source / (1 - g.loss_fraction)
        if gen_variable_cost <= grid_delivered_cost:
            generator_output = min(deficit, generator_limit)
            grid_delivered = min(max(0.0, deficit - generator_output), grid_limit_delivered)
        else:
            grid_delivered = min(deficit, grid_limit_delivered)
            generator_output = min(max(0.0, deficit - grid_delivered), generator_limit)
        fuel_input = generator_output / h.efficiency
        generator_loss = fuel_input - generator_output
        grid_source = grid_delivered / (1 - g.loss_fraction)
        grid_loss = grid_source - grid_delivered
        curtailed_hp_electric = min(max(0.0, deficit - grid_delivered - generator_output), hp_electric_requested)
        hp_electric_consumed = hp_electric_requested - curtailed_hp_electric
        unserved = max(0.0, deficit - grid_delivered - generator_output - curtailed_hp_electric)
        heat_delivered = max(0.0, heat_potential - curtailed_hp_electric * hp.cop)
        heat_unserved = max(0.0, heat_demand - heat_delivered)
        actual_electricity_consumed = base_demand + hp_electric_consumed
        served = actual_electricity_consumed - unserved
        bus_error = renewable + discharge + generator_output + grid_delivered - (served + charge_in + curtailment)
        soc_error = soc_start - self_loss + stored_charge - discharge_withdrawal - soc
        max_bus_error = max(max_bus_error, abs(bus_error))
        max_soc_error = max(max_soc_error, abs(soc_error))
        if soc < -1e-9 or soc > b.capacity_mwh + 1e-9:
            raise AssertionError("internal storage bound violation")
        generator_cost = fuel_input * h.fuel_cost_eur_per_mwh_fuel + generator_output * h.variable_om_eur_per_mwh_electric
        generator_emissions = fuel_input * h.emissions_kg_per_mwh_fuel
        grid_headroom_mw = max(0.0, g.max_import_mw * grid_av[i] * (1 - g.loss_fraction) - grid_delivered / dt)
        generator_headroom_mw = max(0.0, h.capacity_mw * gen_av[i] - generator_output / dt)
        battery_power_available = min(b.power_mw, soc * b.discharge_efficiency / dt)
        battery_headroom_mw = max(0.0, battery_power_available - discharge / dt)
        reserve_available = grid_headroom_mw + generator_headroom_mw + battery_headroom_mw
        reserve_shortfall = max(0.0, s.reserve_requirement_mw - reserve_available)
        interval_unserved = unserved > 1e-9
        if interval_unserved and not previously_unserved:
            loss_events += 1
        previously_unserved = interval_unserved
        loss_hours = dt if interval_unserved else 0.0
        reserve_shortfall_hours = dt if reserve_shortfall > 1e-9 else 0.0
        row = {
            "interval": i, "base_electric_demand_mwh": base_demand,
            "electricity_requested_mwh": requested_electricity, "electricity_consumed_mwh": actual_electricity_consumed,
            "heat_demand_mwh_th": heat_demand, "heat_potential_mwh_th": heat_potential,
            "heat_delivered_mwh_th": heat_delivered, "heat_unserved_mwh_th": heat_unserved,
            "heat_pump_electricity_requested_mwh": hp_electric_requested,
            "heat_pump_electricity_consumed_mwh": hp_electric_consumed,
            "pv_mwh": pv_mw * dt, "wind_mwh": wind_mw * dt, "renewable_mwh": renewable,
            "battery_soc_start_mwh": soc_start, "battery_self_discharge_mwh": self_loss,
            "battery_charge_input_mwh": charge_in, "battery_charge_stored_mwh": stored_charge,
            "battery_discharge_delivered_mwh": discharge, "battery_discharge_withdrawn_mwh": discharge_withdrawal,
            "battery_soc_end_mwh": soc, "generator_availability": gen_av[i],
            "generator_output_mwh": generator_output, "generator_fuel_input_mwh": fuel_input,
            "generator_conversion_loss_mwh": generator_loss, "generator_cost_eur": generator_cost,
            "generator_emissions_kg": generator_emissions, "grid_availability": grid_av[i],
            "grid_delivered_mwh": grid_delivered, "grid_source_mwh": grid_source,
            "grid_transport_loss_mwh": grid_loss, "curtailment_mwh": curtailment,
            "unserved_electric_base_mwh": unserved, "served_electricity_mwh": served,
            "reserve_available_mw": reserve_available, "reserve_shortfall_mw": reserve_shortfall,
            "bus_balance_error_mwh": bus_error, "soc_balance_error_mwh": soc_error,
        }
        rows.append(row)
        pairs = (("base_demand", base_demand), ("electricity_consumed", actual_electricity_consumed), ("electricity_requested", requested_electricity), ("heat_demand", heat_demand), ("heat_delivered", heat_delivered), ("heat_unserved", heat_unserved), ("hp_electricity", hp_electric_consumed), ("renewable", renewable), ("served", served), ("unserved", unserved), ("curtailment", curtailment), ("charge", charge_in), ("discharge", discharge), ("generator", generator_output), ("fuel", fuel_input), ("generator_loss", generator_loss), ("grid_delivered", grid_delivered), ("grid_source", grid_source), ("grid_loss", grid_loss), ("storage_loss", self_loss + charge_in - stored_charge + discharge_withdrawal - discharge), ("grid_cost", grid_source * g.cost_eur_per_mwh_source), ("generator_cost", generator_cost), ("unserved_cost", unserved * s.value_of_lost_load_eur_per_mwh), ("grid_emissions", grid_source * g.emissions_kg_per_mwh_source), ("generator_emissions", generator_emissions), ("loss_hours", loss_hours), ("reserve_available", reserve_available), ("reserve_shortfall", reserve_shortfall * dt), ("reserve_shortfall_hours", reserve_shortfall_hours))
        for key, value in pairs:
            sums[key] += value
    sums["loss_events"] = loss_events
    sums["peak_unserved_mw"] = max((r["unserved_electric_base_mwh"] / dt for r in rows), default=0.0)
    battery_capex = b.capacity_mwh * b.capex_eur_per_mwh + b.power_mw * b.power_capex_eur_per_mw
    generator_capex = h.capacity_mw * h.capex_eur_per_mw
    heat_pump_capex = hp.capacity_mw_th * hp.capex_eur_per_mw_th
    battery_fixed = battery_capex * (annuity_factor(b.discount_rate, b.lifetime_years) + b.annual_opex_fraction)
    generator_fixed = generator_capex * (annuity_factor(h.discount_rate, h.lifetime_years) + h.annual_opex_fraction)
    heat_pump_fixed = heat_pump_capex * (annuity_factor(hp.discount_rate, hp.lifetime_years) + hp.annual_opex_fraction)
    annual_fixed = battery_fixed + generator_fixed + heat_pump_fixed
    annual_days = 365 / (dt * s.n / 24)
    annual_operating = (sums["grid_cost"] + sums["generator_cost"] + sums["unserved_cost"]) * annual_days
    annual_cost = annual_fixed + annual_operating
    system_emissions = sums["grid_emissions"] + sums["generator_emissions"]
    return {
        "scenario": s.name,
        "dispatch_method": "renewable-first, greedy battery; heat pump shed before base load; thermal generator/grid in variable-cost order; no look-ahead",
        "intervals": s.n, "interval_hours": dt,
        "totals": {
            "base_electric_demand_mwh": sums["base_demand"], "electricity_requested_mwh": sums["electricity_requested"],
            "electricity_consumed_mwh": sums["electricity_consumed"], "served_mwh": sums["served"],
            "unserved_mwh": sums["unserved"], "renewable_generation_mwh": sums["renewable"],
            "renewable_curtailment_mwh": sums["curtailment"], "battery_charge_input_mwh": sums["charge"],
            "battery_discharge_delivered_mwh": sums["discharge"], "battery_losses_mwh": sums["storage_loss"],
            "generator_output_mwh": sums["generator"], "generator_fuel_input_mwh": sums["fuel"],
            "generator_conversion_losses_mwh": sums["generator_loss"], "grid_delivered_mwh": sums["grid_delivered"],
            "grid_source_mwh": sums["grid_source"], "grid_transport_loss_mwh": sums["grid_loss"],
            "heat_demand_mwh_th": sums["heat_demand"], "heat_delivered_mwh_th": sums["heat_delivered"],
            "heat_unserved_mwh_th": sums["heat_unserved"], "heat_pump_electricity_consumed_mwh": sums["hp_electricity"],
            "heat_service_fraction": sums["heat_delivered"] / sums["heat_demand"] if sums["heat_demand"] else 1.0,
            "grid_cost_eur": sums["grid_cost"], "generator_cost_eur": sums["generator_cost"],
            "unserved_energy_penalty_eur": sums["unserved_cost"], "grid_emissions_kg": sums["grid_emissions"],
            "generator_emissions_kg": sums["generator_emissions"], "system_emissions_kg": system_emissions,
            "service_fraction": sums["served"] / sums["electricity_consumed"] if sums["electricity_consumed"] else 1.0,
            "loss_of_load_hours": sums["loss_hours"], "loss_of_load_events": sums["loss_events"],
            "peak_unserved_mw": sums["peak_unserved_mw"], "reserve_requirement_mw": s.reserve_requirement_mw,
            "reserve_shortfall_mw_hours": sums["reserve_shortfall"], "reserve_shortfall_hours": sums["reserve_shortfall_hours"],
            "minimum_reserve_available_mw": min(r["reserve_available_mw"] for r in rows),
        },
        "economics": {
            "battery_initial_capex_eur": battery_capex, "generator_initial_capex_eur": generator_capex,
            "heat_pump_initial_capex_eur": heat_pump_capex,
            "annualized_capex_and_fixed_opex_eur_per_year": annual_fixed,
            "annual_equivalent_operating_cost_eur": annual_operating,
            "annual_equivalent_total_cost_eur": annual_cost,
            "annual_equivalent_cost_eur_per_served_mwh": annual_cost / (sums["served"] * annual_days) if sums["served"] else None,
            "annual_equivalent_system_emissions_kg": system_emissions * annual_days,
            "annualization_assumption": "observed profile repeats uniformly to form a 365-day equivalent; not a year-long simulation",
        },
        "checks": {"max_hourly_bus_balance_abs_error_mwh": max_bus_error, "max_storage_balance_abs_error_mwh": max_soc_error, "energy_balance_pass": max_bus_error < 1e-8 and max_soc_error < 1e-8},
        "hourly": rows,
    }


def with_battery(s: Scenario, capacity_mwh: float, power_mw: float) -> Scenario:
    return replace(s, battery=replace(s.battery, capacity_mwh=capacity_mwh, power_mw=power_mw, initial_soc_mwh=min(s.battery.initial_soc_mwh, capacity_mwh)))


def sweep_battery(s: Scenario, capacities_mwh: list[float], powers_mw: list[float]) -> dict[str, Any]:
    if not capacities_mwh or not powers_mw:
        raise ModelError("capacity and power candidate lists cannot be empty")
    caps = [_number(x, "candidate capacity", 0) for x in capacities_mwh]
    powers = [_number(x, "candidate power", 0) for x in powers_mw]
    if len(caps) * len(powers) > 5000:
        raise ModelError("sweep is limited to 5000 candidate combinations")
    candidates = []
    for capacity in caps:
        for power in powers:
            result = simulate(with_battery(s, capacity, power))
            t = result["totals"]
            candidates.append({"capacity_mwh": capacity, "power_mw": power,
                "annual_equivalent_total_cost_eur": result["economics"]["annual_equivalent_total_cost_eur"],
                "unserved_mwh_per_profile": t["unserved_mwh"], "unserved_heat_mwh_th_per_profile": t["heat_unserved_mwh_th"],
                "system_emissions_kg_per_profile": t["system_emissions_kg"], "service_fraction": t["service_fraction"]})
    objectives = ("annual_equivalent_total_cost_eur", "unserved_mwh_per_profile", "unserved_heat_mwh_th_per_profile", "system_emissions_kg_per_profile")
    pareto = [c for c in candidates if not any(all(o[k] <= c[k] for k in objectives) and any(o[k] < c[k] for k in objectives) for o in candidates)]
    candidates.sort(key=lambda x: (x["annual_equivalent_total_cost_eur"], x["unserved_mwh_per_profile"], x["system_emissions_kg_per_profile"], x["capacity_mwh"], x["power_mw"]))
    pareto.sort(key=lambda x: (x["annual_equivalent_total_cost_eur"], x["system_emissions_kg_per_profile"], x["unserved_mwh_per_profile"]))
    best = candidates[0]
    boundary = best["capacity_mwh"] in {min(caps), max(caps)} or best["power_mw"] in {min(powers), max(powers)}
    return {"method": "complete enumeration of supplied discrete capacity x power grid", "optimality_claim": "best point and Pareto set only among supplied candidates; not continuous or global optima", "objectives_minimized": list(objectives), "pareto_front_candidates": pareto, "pareto_front_count": len(pareto), "best_is_on_candidate_grid_boundary": boundary, "boundary_interpretation": "expand the tested range before drawing a sizing conclusion" if boundary else "best tested point is interior to the supplied range", "candidates_tested": len(candidates), "best_tested_by_cost": best, "candidates": candidates}


def run_sensitivity(s: Scenario, demand_scales: list[float], renewable_scales: list[float], grid_price_scales: list[float]) -> dict[str, Any]:
    """Exact deterministic cross-product; scenario cases carry no probability weight."""
    if not demand_scales or not renewable_scales or not grid_price_scales:
        raise ModelError("sensitivity dimensions cannot be empty")
    ds = [_number(x, "demand scale", 0) for x in demand_scales]
    rs = [_number(x, "renewable scale", 0) for x in renewable_scales]
    ps = [_number(x, "grid price scale", 0) for x in grid_price_scales]
    if len(ds) * len(rs) * len(ps) > 2000:
        raise ModelError("sensitivity is limited to 2000 deterministic cases")
    cases = []
    for d in ds:
        for r in rs:
            for p in ps:
                changed = replace(s, name=s.name, demand_mw=tuple(v*d for v in s.demand_mw),
                    pv_mw=tuple(v*r for v in s.pv_mw), wind_mw=tuple(v*r for v in s.wind_mw),
                    grid=replace(s.grid, cost_eur_per_mwh_source=s.grid.cost_eur_per_mwh_source*p))
                result = simulate(changed)
                t, e = result["totals"], result["economics"]
                case_id = f"D{d:g}_R{r:g}_P{p:g}"
                cases.append({"case_id": case_id, "demand_scale": d, "renewable_scale": r, "grid_price_scale": p,
                    "annual_equivalent_total_cost_eur": e["annual_equivalent_total_cost_eur"],
                    "unserved_mwh_per_profile": t["unserved_mwh"], "heat_unserved_mwh_th_per_profile": t["heat_unserved_mwh_th"],
                    "loss_of_load_hours": t["loss_of_load_hours"], "system_emissions_kg_per_profile": t["system_emissions_kg"],
                    "reserve_shortfall_mw_hours": t["reserve_shortfall_mw_hours"], "service_fraction": t["service_fraction"],
                    "energy_balance_pass": result["checks"]["energy_balance_pass"]})
    return {"method": "deterministic full-factorial parameter grid", "probability_interpretation": "none; scenarios are not probabilities", "cases_tested": len(cases), "worst_service_case": min(cases, key=lambda x: (x["service_fraction"], -x["unserved_mwh_per_profile"])), "lowest_cost_case": min(cases, key=lambda x: x["annual_equivalent_total_cost_eur"]), "highest_emissions_case": max(cases, key=lambda x: x["system_emissions_kg_per_profile"]), "cases": cases}
