from .model import VERSION

__version__ = VERSION
