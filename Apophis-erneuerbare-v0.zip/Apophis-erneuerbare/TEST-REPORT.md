# Testprotokoll — Energy Lighthouse 0.3.0

Stand: 2026-10-22 UTC. Umgebung: Python 3.12.3 auf Ubuntu Linux; nur Standardbibliothek. Sämtliche mitgelieferten Profile und Technologieannahmen sind als synthetisch markiert, keine Messwerte.

## Automatisierte Tests

Befehl: `PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -v`

**23 Tests bestanden, 0 fehlgeschlagen.** Neben Strom-/Speicher-/Generator-/CSV-Regressionen prüfen die neuen Tests Netz- und Generator-Verfügbarkeitsprofile, stündliche Loss-of-Load-Stunden/Ereignisse und Spitzenlastabwurf, die elektrische und thermische Wärmepumpenbilanz einschließlich Abregelpriorität, Reservekurzfall, 8 deterministische Sensitivitätsfälle und deren Obergrenze, JSON-Profileinlesen sowie den thermischen CSV-Import.

## Tatsächlich ausgeführte Integrationsläufe

### Referenzprofil

24 stündliche Intervalle: 175,200 MWh Basisstromnachfrage, 144,100 MWh PV/Wind, 36,003 MWh gelieferter Netzbezug und 11,397 MWh Batterieabgabe. 0 MWh ungedeckt; 0 Loss-of-Load-Stunden. Die elektrische Busbilanz besteht mit maximalem Fehler `1,78 × 10⁻¹⁵ MWh`, die Speicherbilanz mit 0 MWh Fehler. Die Mindestreserve wird mit 3,300 MW ausgewiesen, aber ohne gesetzte Reserveanforderung nicht als Bedarf interpretiert.

### Wärmepumpe

Im synthetischen Beispiel beträgt die Wärmelast 32,500 MWh_th. Die Wärmepumpe liefert dieselbe Wärme mit COP 3, verbraucht 10,833 MWh Strom und deckt 100 % der Wärmelast. Strombilanzfehler maximal `1,78 × 10⁻¹⁵ MWh`. Ein Unit-Test erzwingt Stromknappheit und bestätigt, dass die Wärmepumpe vor der elektrischen Grundlast gekürzt wird; dadurch wird Wärme als ungedeckt statt als elektrische Grundlast-Unterversorgung ausgewiesen.

### Zeitabhängige Ausfälle und Reserve

Das synthetische Zeitprofil enthält einen Netzausfall über drei Intervalle, eine kurzzeitige Deratierung und einen Generatorausfall. Bei 2 MW Reserveanforderung ergab die Simulation 98,09 % elektrische Versorgung, 3,352 MWh nicht gedeckte Grundlast, 2 Loss-of-Load-Stunden, ein Ereignis und 1,802 MW Spitzenabwurf. Die statische Reservekennzahl unterschritt die Anforderung über 2 Stunden um insgesamt 4,000 MW·h. Busbilanztest bestanden. Diese Eingabe ist ein deterministischer Demonstrator, keine empirische Ausfallstatistik.

### Sensitivität, Stresstest und Batterie-Pareto

Eine Matrix aus 3 Nachfragefaktoren × 3 Erneuerbarenfaktoren × 3 Netzpreisfaktoren wurde vollständig mit **27 deterministischen Fällen** berechnet. Alle Fälle bestehen die Energiebilanz. Die Ergebnisse vergeben keine Wahrscheinlichkeit an einen Fall.

Der Batterie-Sweep enumerierte 30 Kandidaten und gab 10 diskrete Pareto-Punkte aus. Das Raster und alle Kosten-/Emissionswerte beruhen auf synthetischen Eingaben. Der Sechs-Fälle-Stresstest wurde ebenfalls erneut ausgeführt; alle sechs Energiebilanzen bestanden.

## Grenzen der neuen Funktionen

- Wärmepumpe: konstanter COP, keine wetterabhängigen Leistungszahlen, Speichermasse, thermische Trägheit oder Komfortgrenzen; unterbrechbare Last wird zuerst gekürzt.
- Zeitprofile: Verfügbarkeit wird als Eingabe angenommen. Es werden weder Wahrscheinlichkeiten noch empirische Ausfallhäufigkeiten abgeleitet.
- Loss-of-load: Stunden, Ereignisse, Energie und Spitzenleistung beziehen sich nur auf die eingegebene Chronologie; keine statistischen Erwartungswerte.
- Reserve: einfache statische Summierung verfügbarer Margen; keine Rampen-/Reaktionszeit-, N-1- oder Netzstabilitätsprüfung.
- Sensitivität: deterministisches vollständiges Produkt für Nachfrage, PV/Wind gemeinsam und Netzpreis, maximal 2.000 Fälle; keine Monte-Carlo-Auswertung oder Unsicherheitsverteilung.
- Dispatch, annualisierte Kosten und Emissionen behalten alle Einschränkungen des früheren Testprotokolls: heuristisch, keine Jahressimulation, unvalidierte Annahmen.

Ergebnisse und reproduzierbare Eingaben liegen unter `runs/v0.3/`. Hashes verifizieren nur Byte-Identität. Externe Beispieldaten müssen vor einer späteren Integration anhand ihrer Herausgeberdokumentation, Lizenz, Einheiten, Zeitstempel und Qualität geprüft werden.
