# Energy Lighthouse v0.7 — Block-4-Bericht

## Zeitgekoppelte Betriebslogik

Der Dispatch berücksichtigt nun Batterie-Selbstentladung und eine transparente zyklische Kapazitätsdegradation. Die Degradation basiert auf der im Arbeitsdatensatz enthaltenen Batterie-Zyklenannahme und ist auf den angegebenen End-of-Life-Anteil begrenzt. Lade- und Entladeenergie erhöhen den kumulierten Durchsatz.

Der H₂-Speicher verliert stündlich den aus dem Datensatz übernommenen Tagesverlustanteil. Speicherverluste werden separat in Kilogramm ausgewiesen und nicht stillschweigend der Nachfrage oder Abregelung zugerechnet.

Der nationale Import besitzt ein konfigurierbares Rampenlimit. Der vorherige Stundenwert wird als Betriebszustand weitergeführt. Reservekurzfall und Importlimit werden getrennt ausgewiesen.

## Nachweise

`PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -q` ergibt **29/29 bestanden**. Der 168-Stunden-Lauf unter `runs/v0.7-storage-ramp-168h/` weist 540,218 MWh Degradationsproxy, 2,687 kg H₂-Speicherverlust und 1.510.261,089 MWh Reservekurzfall aus. Die Nachfragebilanz besteht.

Die Implementierung bleibt ein transparenter R1-Forschungsprototyp. Die Rampen- und Reservewerte sind keine Frequenz- oder Anlagenfahrplanprüfung; Batterie-Degradation ist ein vereinfachter Zyklenproxy; der H₂-Verlust ist eine Arbeitsannahme. Für eine Produktionsstudie wären Anlagencluster, Mindestlasten, Startkosten, echte Rampenkennlinien und ein validiertes Mehrperiodenoptimierungsmodell erforderlich.
