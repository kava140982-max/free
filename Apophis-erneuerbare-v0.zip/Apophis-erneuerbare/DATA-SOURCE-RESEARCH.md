

## Tatsächlich im ZIP enthalten

Das eigenständige Projekt enthält drei vollständige, bereits lokal verfügbare Quelldateien: PGLib IEEE-14-Bus (`.m`), das Geoscience-Australia-GIS-Originalarchiv (`.zip`) und das NLR-Elektrolyseur-Beispielarchiv (`.zip`). Zusätzlich liegt eine einzelne, quellenattribuierte NLR-Datensatzzeile als CSV bei. Herkunft, Nutzungsbedingungen, Abgrenzungen und SHA-256 stehen in [`data/verified_samples/README.md`](data/verified_samples/README.md) und `data/verified_samples/DATASET-MANIFEST.json`. Es wurden nach dem Abbruch keine weiteren Server angesprochen. Die offenen Bereiche oben bleiben ungeprüft.
