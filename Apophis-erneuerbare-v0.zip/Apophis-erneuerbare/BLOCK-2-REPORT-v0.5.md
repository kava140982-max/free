# Energy Lighthouse v0.5 — Block-2-Bericht

## Änderungen

Der EV-Zeitreihenfehler wurde behoben: Die Last wird jetzt mit der vollständigen 8.760-Stunden-Demand-Indexsumme normalisiert. Für die Baseline ergeben sich damit exakt 12,8 TWh EV-Energie gemäß `16 TWh × 0,80`. Die Stundenreports enthalten nun die gekoppelte Gesamtlast inklusive EV- und Wärmepumpenanteil statt nur der Basislast.

Zusätzlich prüft jeder integrierte Lauf die Invariante `served_mwh + unserved_mwh = demand_mwh` pro Stunde und die Summenidentität über die Zeitreihe. Die Ergebnisse stehen unter `result.checks` und werden fail-closed getestet.

Der neue `design-sweep` enumeriert ein begrenztes Designraster über Wärmepumpenanteil, flexible Last, H₂-Speicherkapazität und nationales Importlimit. Kosten, CO₂, Strom-/Wärmeversorgung und H₂-Erzeugung werden verglichen. Die Paretofront minimiert Betriebskosten, nicht gedeckte Strom- und Wärmeenergie sowie CO₂. Das Verfahren ist eine vollständige Enumeration des gelieferten Rasters, aber keine kontinuierliche oder globale Optimierung.

## Nachweise

`PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -q` ergibt **29/29 bestanden**. Der 168-Stunden-Design-Sweep berechnet 54 Fälle; die Ausgabe liegt unter `runs/v0.5-design-sweep-168h/design-sweep.json`.

Die neuen Funktionen ändern die Evidenzgrenze nicht: Modellannahmen und synthetische Zeitreihen bleiben nicht unabhängig validiert. Der Netztransport ist weiterhin aggregiert, und es gibt keinen AC/DC-Leistungsfluss, keine N-1-Prüfung und keinen mathematischen Optimalitätsnachweis.
