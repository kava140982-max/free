import tempfile
import unittest
from pathlib import Path

from energy_lighthouse.model import (
    Battery, DispatchableGenerator, Grid, HeatPump, ModelError, Scenario, simulate,
    sweep_battery, run_sensitivity,
)
from energy_lighthouse.io import import_timeseries_csv, load_scenario


def make_scenario(demand, pv, wind, battery=None, grid=None, dt=1.0, generator=None, heat_pump=None, thermal=(), reserve=0.0):
    return Scenario("test", dt, tuple(demand), tuple(pv), tuple(wind), battery or Battery(), grid or Grid(), 10_000, "synthetic test", generator or DispatchableGenerator(), heat_pump or HeatPump(), tuple(thermal), reserve)


class ModelTests(unittest.TestCase):
    def test_renewable_supply_is_balanced_and_curtailment_reported(self):
        r = simulate(make_scenario([1], [3], [0], grid=Grid(max_import_mw=0)))
        self.assertAlmostEqual(r["totals"]["renewable_curtailment_mwh"], 2)
        self.assertAlmostEqual(r["totals"]["unserved_mwh"], 0)
        self.assertTrue(r["checks"]["energy_balance_pass"])

    def test_battery_round_trip_efficiency_and_soc(self):
        b = Battery(capacity_mwh=2, power_mw=2, charge_efficiency=.8, discharge_efficiency=.5, self_discharge_per_hour=0)
        r = simulate(make_scenario([0, 1], [2, 0], [0, 0], b, Grid(max_import_mw=0)))
        self.assertAlmostEqual(r["hourly"][0]["battery_charge_input_mwh"], 2)
        self.assertAlmostEqual(r["hourly"][0]["battery_soc_end_mwh"], 1.6)
        self.assertAlmostEqual(r["hourly"][1]["battery_discharge_delivered_mwh"], .8)
        self.assertAlmostEqual(r["hourly"][1]["battery_soc_end_mwh"], 0)
        self.assertTrue(r["checks"]["energy_balance_pass"])

    def test_grid_limit_and_transmission_losses(self):
        g = Grid(max_import_mw=2, loss_fraction=.1, cost_eur_per_mwh_source=100, emissions_kg_per_mwh_source=50)
        r = simulate(make_scenario([3], [0], [0], grid=g))
        self.assertAlmostEqual(r["hourly"][0]["grid_delivered_mwh"], 1.8)
        self.assertAlmostEqual(r["hourly"][0]["grid_source_mwh"], 2)
        self.assertAlmostEqual(r["hourly"][0]["grid_transport_loss_mwh"], .2)
        self.assertAlmostEqual(r["totals"]["unserved_mwh"], 1.2)

    def test_self_discharge_applied(self):
        b = Battery(capacity_mwh=10, power_mw=0, initial_soc_mwh=10, self_discharge_per_hour=.1)
        r = simulate(make_scenario([0], [0], [0], b, Grid(max_import_mw=0)))
        self.assertAlmostEqual(r["hourly"][0]["battery_self_discharge_mwh"], 1)
        self.assertAlmostEqual(r["hourly"][0]["battery_soc_end_mwh"], 9)

    def test_bad_efficiency_is_rejected(self):
        with self.assertRaises(ModelError):
            simulate(make_scenario([1], [0], [0], Battery(charge_efficiency=1.1)))

    def test_generator_fuel_energy_cost_emissions_and_merit_order(self):
        gen = DispatchableGenerator(capacity_mw=3, availability=1, efficiency=.5,
                                    fuel_cost_eur_per_mwh_fuel=40,
                                    variable_om_eur_per_mwh_electric=10,
                                    emissions_kg_per_mwh_fuel=50, capex_eur_per_mw=0)
        grid = Grid(max_import_mw=1, loss_fraction=0, cost_eur_per_mwh_source=100,
                    emissions_kg_per_mwh_source=200)
        r = simulate(make_scenario([4], [0], [0], grid=grid, generator=gen))
        row = r["hourly"][0]
        self.assertAlmostEqual(row["generator_output_mwh"], 3)
        self.assertAlmostEqual(row["generator_fuel_input_mwh"], 6)
        self.assertAlmostEqual(row["generator_cost_eur"], 270)
        self.assertAlmostEqual(row["generator_emissions_kg"], 300)
        self.assertAlmostEqual(row["grid_delivered_mwh"], 1)
        self.assertAlmostEqual(r["totals"]["system_emissions_kg"], 500)
        self.assertTrue(r["checks"]["energy_balance_pass"])

    def test_expensive_generator_is_held_back_for_cheaper_grid(self):
        gen = DispatchableGenerator(capacity_mw=3, efficiency=.4, fuel_cost_eur_per_mwh_fuel=100,
                                    variable_om_eur_per_mwh_electric=10, capex_eur_per_mw=0)
        grid = Grid(max_import_mw=4, loss_fraction=0, cost_eur_per_mwh_source=100)
        r = simulate(make_scenario([3], [0], [0], grid=grid, generator=gen))
        self.assertAlmostEqual(r["hourly"][0]["grid_delivered_mwh"], 3)
        self.assertAlmostEqual(r["hourly"][0]["generator_output_mwh"], 0)

    def test_sweep_is_repeatable_and_candidate_count_is_exact(self):
        s = make_scenario([1, 1], [2, 0], [0, 0], grid=Grid(max_import_mw=2))
        a = sweep_battery(s, [0, 1], [0, 1])
        b = sweep_battery(s, [0, 1], [0, 1])
        self.assertEqual(a, b)
        self.assertEqual(a["candidates_tested"], 4)
        self.assertGreaterEqual(a["pareto_front_count"], 1)
        self.assertTrue(all("system_emissions_kg_per_profile" in x for x in a["pareto_front_candidates"]))

    def test_sweep_candidate_budget_is_bounded(self):
        s = make_scenario([1], [0], [0])
        with self.assertRaises(ModelError):
            sweep_battery(s, [1] * 71, [1] * 71)

    def test_reference_input_loads(self):
        p = Path(__file__).parents[1] / "examples" / "reference.json"
        s, digest = load_scenario(p)
        self.assertEqual(s.n, 24)
        self.assertEqual(len(digest), 64)
        self.assertEqual(s.generator.capacity_mw, 3)

    def test_duplicate_json_keys_are_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "bad.json"
            p.write_text('{"name":"x","name":"y"}', encoding="utf-8")
            with self.assertRaises(ValueError):
                load_scenario(p)

    def test_csv_import_with_utc_timestamps_and_reload(self):
        with tempfile.TemporaryDirectory() as d:
            source = Path(d) / "profile.csv"
            out = Path(d) / "scenario.json"
            source.write_text("timestamp,demand_mw,pv_mw,wind_mw\n2026-01-01T00:00:00Z,2,0,1\n2026-01-01T01:00:00Z,3,1,1\n", encoding="utf-8")
            meta = import_timeseries_csv(source, out, "csv-test", 1)
            s, digest = load_scenario(out)
            self.assertEqual(s.demand_mw, (2.0, 3.0))
            self.assertTrue(meta["timestamps_checked"])
            self.assertEqual(len(digest), 64)

    def test_csv_import_rejects_irregular_timestamp_intervals(self):
        with tempfile.TemporaryDirectory() as d:
            source = Path(d) / "bad.csv"
            source.write_text("timestamp,demand_mw,pv_mw,wind_mw\n2026-01-01T00:00:00Z,2,0,1\n2026-01-01T02:00:00Z,3,1,1\n", encoding="utf-8")
            with self.assertRaises(ValueError):
                import_timeseries_csv(source, Path(d) / "scenario.json", "bad", 1)

    def test_csv_import_rejects_output_equal_to_source(self):
        with tempfile.TemporaryDirectory() as d:
            source = Path(d) / "profile.csv"
            source.write_text("demand_mw,pv_mw,wind_mw\n2,0,1\n", encoding="utf-8")
            with self.assertRaises(ValueError):
                import_timeseries_csv(source, source, "bad", 1)

    def test_grid_availability_profile_and_loss_of_load_metrics(self):
        grid = Grid(max_import_mw=2, loss_fraction=0, availability=(1, 0, 1, 0))
        result = simulate(make_scenario([1, 1, 0, 1], [0]*4, [0]*4, grid=grid))
        totals = result["totals"]
        self.assertAlmostEqual(totals["unserved_mwh"], 2)
        self.assertAlmostEqual(totals["loss_of_load_hours"], 2)
        self.assertEqual(totals["loss_of_load_events"], 2)
        self.assertAlmostEqual(totals["peak_unserved_mw"], 1)
        self.assertTrue(result["checks"]["energy_balance_pass"])

    def test_generator_availability_can_change_each_interval(self):
        gen = DispatchableGenerator(capacity_mw=2, availability=(1, 0), efficiency=1,
                                    fuel_cost_eur_per_mwh_fuel=0, variable_om_eur_per_mwh_electric=0,
                                    capex_eur_per_mw=0)
        result = simulate(make_scenario([1, 1], [0, 0], [0, 0], grid=Grid(max_import_mw=0), generator=gen))
        self.assertEqual([x["generator_output_mwh"] for x in result["hourly"]], [1, 0])
        self.assertAlmostEqual(result["totals"]["unserved_mwh"], 1)

    def test_heat_pump_couples_electricity_and_thermal_service(self):
        hp = HeatPump(capacity_mw_th=2, cop=2)
        result = simulate(make_scenario([1], [2], [0], grid=Grid(max_import_mw=0),
                                        heat_pump=hp, thermal=[2]))
        t = result["totals"]
        self.assertAlmostEqual(t["heat_delivered_mwh_th"], 2)
        self.assertAlmostEqual(t["heat_pump_electricity_consumed_mwh"], 1)
        self.assertAlmostEqual(t["electricity_consumed_mwh"], 2)
        self.assertAlmostEqual(t["heat_service_fraction"], 1)
        self.assertTrue(result["checks"]["energy_balance_pass"])

    def test_heat_pump_is_shed_before_base_load_when_power_is_scarce(self):
        hp = HeatPump(capacity_mw_th=2, cop=2)
        result = simulate(make_scenario([4], [4], [0], grid=Grid(max_import_mw=0),
                                        heat_pump=hp, thermal=[2]))
        t = result["totals"]
        self.assertAlmostEqual(t["unserved_mwh"], 0)
        self.assertAlmostEqual(t["heat_unserved_mwh_th"], 2)
        self.assertAlmostEqual(t["electricity_consumed_mwh"], 4)
        self.assertTrue(result["checks"]["energy_balance_pass"])

    def test_reserve_headroom_and_shortfall_are_explicit(self):
        gen = DispatchableGenerator(capacity_mw=2, efficiency=1, fuel_cost_eur_per_mwh_fuel=0,
                                    variable_om_eur_per_mwh_electric=0, capex_eur_per_mw=0)
        result = simulate(make_scenario([1], [0], [0], grid=Grid(max_import_mw=0), generator=gen, reserve=2))
        t = result["totals"]
        self.assertAlmostEqual(t["minimum_reserve_available_mw"], 1)
        self.assertAlmostEqual(t["reserve_shortfall_mw_hours"], 1)
        self.assertAlmostEqual(t["reserve_shortfall_hours"], 1)

    def test_deterministic_sensitivity_cartesian_product_has_no_probabilities(self):
        s = make_scenario([1], [0.25], [0.25])
        result = run_sensitivity(s, [0.9, 1.1], [0.8, 1.2], [0.5, 1.5])
        self.assertEqual(result["cases_tested"], 8)
        self.assertEqual(len({x["case_id"] for x in result["cases"]}), 8)
        self.assertIn("probabilities", result["probability_interpretation"])
        self.assertTrue(all(x["energy_balance_pass"] for x in result["cases"]))

    def test_sensitivity_case_budget_is_bounded(self):
        s = make_scenario([1], [0], [0])
        with self.assertRaises(ModelError):
            run_sensitivity(s, [1]*13, [1]*13, [1]*13)

    def test_heat_pump_scenario_json_roundtrip_with_availability_profiles(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "scenario.json"
            p.write_text('{"name":"profiles","interval_hours":1,"demand_mw":[1,1],"pv_mw":[0,0],"wind_mw":[0,0],"thermal_demand_mw_th":[2,3],"heat_pump":{"capacity_mw_th":2,"cop":2},"grid":{"max_import_mw":1,"availability":[1,0]},"generator":{"capacity_mw":1,"availability":[0.5,1]},"reserve_requirement_mw":0.5}', encoding="utf-8")
            s, _ = load_scenario(p)
            self.assertEqual(s.grid.availability, (1, 0))
            self.assertEqual(s.generator.availability, (0.5, 1))
            result = simulate(s)
            self.assertEqual(result["intervals"], 2)
            self.assertTrue(result["checks"]["energy_balance_pass"])

    def test_thermal_csv_column_is_imported(self):
        with tempfile.TemporaryDirectory() as d:
            source, target = Path(d)/"profile.csv", Path(d)/"scenario.json"
            source.write_text("demand_mw,pv_mw,wind_mw,thermal_demand_mw_th\n1,0,0,2\n", encoding="utf-8")
            meta = import_timeseries_csv(source, target, "heat", 1)
            s, _ = load_scenario(target)
            self.assertTrue(meta["thermal_profile_imported"])
            self.assertEqual(s.thermal_demand_mw_th, (2.0,))


if __name__ == "__main__":
    unittest.main()
