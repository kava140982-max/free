import json
import tempfile
import unittest
from pathlib import Path
from energy_lighthouse.integrated import IntegratedModelError, IntegratedOptions, load_working_data, simulate_integrated, run_catalog, run_design_sweep

ROOT = Path(__file__).parents[1]
DATA = ROOT / "data" / "energy_lighthouse_working_data_0.1.json"

class IntegratedTests(unittest.TestCase):
    def test_full_dataset_has_8760_rows_and_roles(self):
        data, digest = load_working_data(DATA)
        self.assertEqual(len(digest), 64)
        self.assertEqual(len(data["synthetic_hourly_profiles_2025"]["rows"]), 8760)
        self.assertEqual(data["synthetic_hourly_profiles_2025"]["rows"][0]["data_role"], "SYNTHETIC_TEST_DATA")

    def test_integrated_smoke_couples_regions_heat_ev_hydrogen_and_network(self):
        data, _ = load_working_data(DATA)
        result = simulate_integrated(data, IntegratedOptions(scenario_id="baseline_2026", stress_id="dark_doldrums_72h", hours_limit=24))
        self.assertEqual(result["intervals"], 24)
        self.assertTrue(result["data_evidence"]["not_a_certification"])
        self.assertGreater(result["totals"]["demand_mwh"], 0)
        self.assertGreater(result["totals"]["heat_demand_mwh_th"], 0)
        self.assertGreater(result["totals"]["ev_mwh"], 0)
        self.assertGreaterEqual(result["totals"]["interregional_exchange_mwh"], 0)
        self.assertGreaterEqual(result["totals"]["interregional_loss_mwh"], 0)
        self.assertGreaterEqual(result["reliability"]["reserve_shortfall_hours"], 0)
        self.assertTrue(result["checks"]["demand_balance_pass"])

    def test_full_year_ev_profile_preserves_configured_annual_transport_energy(self):
        data, _ = load_working_data(DATA)
        result = simulate_integrated(data, IntegratedOptions(scenario_id="baseline_2026"))
        expected = 16_000_000 * 0.80 * 1.0
        self.assertAlmostEqual(result["totals"]["ev_mwh"], expected, delta=1e-3)
        self.assertGreaterEqual(result["totals"]["h2_storage_loss_kg"], 0)
        self.assertGreaterEqual(result["totals"]["battery_degradation_mwh"], 0)

    def test_unknown_scenario_and_stress_are_rejected(self):
        data, _ = load_working_data(DATA)
        with self.assertRaises(IntegratedModelError):
            simulate_integrated(data, IntegratedOptions(scenario_id="does-not-exist", hours_limit=1))
        with self.assertRaises(IntegratedModelError):
            simulate_integrated(data, IntegratedOptions(scenario_id="baseline_2026", stress_id="does-not-exist", hours_limit=1))

    def test_catalog_enumerates_all_scenarios_and_stresses_deterministically(self):
        data, _ = load_working_data(DATA)
        result = run_catalog(data, hours_limit=2)
        self.assertEqual(result["cases_tested"], 42)
        self.assertIn("no probabilities", result["method"])
        self.assertTrue(result["not_a_certification"])

    def test_design_sweep_is_bounded_and_has_explicit_pareto_limit(self):
        data, _ = load_working_data(DATA)
        result = run_design_sweep(data, scenario_id="baseline_2026", heat_pump_shares=(0.3, 0.4), flexible_fractions=(0.08,), hydrogen_storage_kg=(250_000.0,), import_limits_mw=(20_000.0, 30_000.0), hours_limit=2)
        self.assertEqual(result["cases_tested"], 4)
        self.assertGreaterEqual(result["pareto_front_count"], 1)
        self.assertIn("no continuous/global optimum", result["method"])
        self.assertTrue(all(x["demand_balance_pass"] for x in result["cases"]))

if __name__ == "__main__":
    unittest.main()
