# Energiebilanz: synthetic-24h-heat-pump-coupling

- Dispatch: renewable-first, greedy battery; heat pump shed before base load; thermal generator/grid in variable-cost order; no look-ahead
- Zeitreihe: 24 × 1.0 h
- Basisstrom: 175.200 MWh; tatsächlich verbraucht: 186.033 MWh; ungedeckte Grundlast: 0.000 MWh
- Erneuerbare Erzeugung: 144.100 MWh; Abregelung: 5.076 MWh
- Wärmelast: 32.500 MWh_th; geliefert: 32.500 MWh_th; ungedeckt: 0.000 MWh_th; Wärmepumpenstrom: 10.833 MWh
- Generator: 0.600 MWh_el aus 1.500 MWh_fuel; Umwandlungsverlust: 0.900 MWh
- Netzbezug: 43.436 MWh; Leitungsverlust: 1.343 MWh; Systememissionen: 11497.8 kg (angenommen)
- Versorgung: 100.00%; LOLE: 0.000 h in 0 Ereignissen; Spitzenlastabwurf: 0.000 MW
- Reserveanforderung: 0.000 MW; Mindestreserve: 2.367 MW; Reservefehlstunden: 0.000 h
- Annualäquivalente Systemkosten: 2343289.52 €; Bilanztest: BESTANDEN (max. Busfehler 1.78e-15 MWh)

Jahreskosten unterstellen eine gleichförmige Wiederholung des Eingabeprofils, keine Jahressimulation. Parameter und Emissionsfaktoren sind Annahmen; keine Netzstabilitätsprüfung.

Details: `report.json`, `hourly.csv`; wiederholbare Eingabe: `scenario.input.json` (SHA-256 `981576b596b660928fa0f05ae974cdc48eb6b1fb2fa046ec2f285e4690f97e22`). Hashes beweisen keine inhaltliche Richtigkeit.
