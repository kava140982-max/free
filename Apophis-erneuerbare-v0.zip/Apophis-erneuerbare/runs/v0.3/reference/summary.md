# Energiebilanz: synthetic-24h-island-grid

- Dispatch: renewable-first, greedy battery; heat pump shed before base load; thermal generator/grid in variable-cost order; no look-ahead
- Zeitreihe: 24 × 1.0 h
- Basisstrom: 175.200 MWh; tatsächlich verbraucht: 175.200 MWh; ungedeckte Grundlast: 0.000 MWh
- Erneuerbare Erzeugung: 144.100 MWh; Abregelung: 7.876 MWh
- Wärmelast: 0.000 MWh_th; geliefert: 0.000 MWh_th; ungedeckt: 0.000 MWh_th; Wärmepumpenstrom: 0.000 MWh
- Generator: 0.000 MWh_el aus 0.000 MWh_fuel; Umwandlungsverlust: 0.000 MWh
- Netzbezug: 36.003 MWh; Leitungsverlust: 1.113 MWh; Systememissionen: 9279.1 kg (angenommen)
- Versorgung: 100.00%; LOLE: 0.000 h in 0 Ereignissen; Spitzenlastabwurf: 0.000 MW
- Reserveanforderung: 0.000 MW; Mindestreserve: 3.300 MW; Reservefehlstunden: 0.000 h
- Annualäquivalente Systemkosten: 1932637.32 €; Bilanztest: BESTANDEN (max. Busfehler 1.78e-15 MWh)

Jahreskosten unterstellen eine gleichförmige Wiederholung des Eingabeprofils, keine Jahressimulation. Parameter und Emissionsfaktoren sind Annahmen; keine Netzstabilitätsprüfung.

Details: `report.json`, `hourly.csv`; wiederholbare Eingabe: `scenario.input.json` (SHA-256 `c8f2860428943da2644767d2bee7f20fe877c898c5c160dccb1fa3182aa01d0b`). Hashes beweisen keine inhaltliche Richtigkeit.
