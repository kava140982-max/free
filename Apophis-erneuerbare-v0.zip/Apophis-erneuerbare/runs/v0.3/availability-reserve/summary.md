# Energiebilanz: synthetic-24h-outage-and-reserve-demo

- Dispatch: renewable-first, greedy battery; heat pump shed before base load; thermal generator/grid in variable-cost order; no look-ahead
- Zeitreihe: 24 × 1.0 h
- Basisstrom: 175.200 MWh; tatsächlich verbraucht: 175.200 MWh; ungedeckte Grundlast: 3.352 MWh
- Erneuerbare Erzeugung: 144.100 MWh; Abregelung: 7.876 MWh
- Wärmelast: 0.000 MWh_th; geliefert: 0.000 MWh_th; ungedeckt: 0.000 MWh_th; Wärmepumpenstrom: 0.000 MWh
- Generator: 3.450 MWh_el aus 8.625 MWh_fuel; Umwandlungsverlust: 5.175 MWh
- Netzbezug: 29.201 MWh; Leitungsverlust: 0.903 MWh; Systememissionen: 9268.2 kg (angenommen)
- Versorgung: 98.09%; LOLE: 2.000 h in 1 Ereignissen; Spitzenlastabwurf: 1.802 MW
- Reserveanforderung: 2.000 MW; Mindestreserve: 0.000 MW; Reservefehlstunden: 2.000 h
- Annualäquivalente Systemkosten: 14151558.47 €; Bilanztest: BESTANDEN (max. Busfehler 1.78e-15 MWh)

Jahreskosten unterstellen eine gleichförmige Wiederholung des Eingabeprofils, keine Jahressimulation. Parameter und Emissionsfaktoren sind Annahmen; keine Netzstabilitätsprüfung.

Details: `report.json`, `hourly.csv`; wiederholbare Eingabe: `scenario.input.json` (SHA-256 `f63a856344f890554b482352b080e47e323879be39818b4012dddcfe66842bf6`). Hashes beweisen keine inhaltliche Richtigkeit.
