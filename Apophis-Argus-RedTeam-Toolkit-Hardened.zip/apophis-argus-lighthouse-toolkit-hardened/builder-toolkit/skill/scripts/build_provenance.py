#!/usr/bin/env python3
"""Create unsigned SLSA v1 provenance metadata for later CI attestation."""
import argparse
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path

def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""): h.update(chunk)
    return h.hexdigest()

def main():
    p = argparse.ArgumentParser(); p.add_argument("--artifact", action="append", required=True); p.add_argument("--output", type=Path, required=True); args = p.parse_args()
    subjects = []
    for item in args.artifact:
        path = Path(item); subjects.append({"name": str(path), "digest": {"sha256": digest(path)}})
    repo = os.environ.get("GITHUB_REPOSITORY", "local/unknown")
    commit = os.environ.get("GITHUB_SHA", "unknown")
    invocation = os.environ.get("GITHUB_RUN_ID", "local-run")
    statement = {
      "_type": "https://in-toto.io/Statement/v1",
      "subject": subjects,
      "predicateType": "https://slsa.dev/provenance/v1",
      "predicate": {
        "buildDefinition": {
          "buildType": "https://github.com/Attestations/GitHub Actions@v1",
          "externalParameters": {"repository": repo, "commit": commit},
          "resolvedDependencies": [{"uri": f"git+https://github.com/{repo}", "digest": {"gitCommit": commit}}]
        },
        "runDetails": {
          "builder": {"id": "local-or-github-actions", "version": {"generator": "apophis-lighthouse-builder"}},
          "metadata": {"invocationId": invocation, "startedOn": datetime.now(timezone.utc).isoformat()}
        }
      },
      "apophis": {"schema": "apophis/unsigned-provenance/v1", "signed": False, "not_a_certification": True}
    }
    args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(statement, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"verdict":"PASS","output":str(args.output),"subjects":len(subjects),"signed":False,"not_a_certification":True}, indent=2))

if __name__ == "__main__": main()
