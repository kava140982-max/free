#!/usr/bin/env python3
"""Build a human-readable and machine-readable catalog from module manifests."""
import argparse
import html
import json
from pathlib import Path
from validate_catalog import validate

LEVEL_LABELS = {"present": "present", "internally_tested": "internally tested", "externally_confirmed": "externally confirmed"}

def cell(value):
    """Escape untrusted manifest values before placing them in Markdown/HTML."""
    return html.escape(str(value), quote=True).replace("|", "\\|").replace("\n", " ")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest_dir", type=Path)
    parser.add_argument("--root", type=Path, default=None)
    parser.add_argument("--markdown", type=Path, required=True)
    parser.add_argument("--json", dest="json_path", type=Path, required=True)
    args = parser.parse_args()
    root = (args.root or args.manifest_dir.parent).resolve()
    errors = validate(args.manifest_dir.resolve(), root)
    if errors:
        print(json.dumps({"verdict": "FAILED", "errors": errors}, indent=2))
        return 1
    rows = [json.loads(p.read_text(encoding="utf-8")) for p in sorted(args.manifest_dir.glob("*.json"))]
    rows.sort(key=lambda m: m["id"])
    markdown = ["# Module Catalog", "", "<!-- generated; do not edit manually -->", "", f"Modules: {len(rows)}", "", "| ID | Domain | Kind | Maturity | Network | Core access | Primary limit |", "|---|---|---|---|---|---|---|"]
    for m in rows:
        markdown.append(f"| `{cell(m['id'])}` | {cell(m.get('domain', m.get('name','')))} | {cell(m['kind'])} | {cell(LEVEL_LABELS[m['maturity']['level']])} | {cell(m['network'])} | {cell(m['core_access'])} | {cell(m['limits'][0])} |")
    markdown += ["", "This catalog is an inventory and not a certification.", ""]
    args.markdown.parent.mkdir(parents=True, exist_ok=True); args.markdown.write_text("\n".join(markdown), encoding="utf-8")
    index = {"schema": "apophis/module-catalog/v1", "modules": rows, "not_a_certification": True}
    args.json_path.parent.mkdir(parents=True, exist_ok=True); args.json_path.write_text(json.dumps(index, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"verdict": "PASS", "modules": len(rows), "markdown": str(args.markdown), "json": str(args.json_path), "not_a_certification": True}, indent=2))

if __name__ == "__main__": raise SystemExit(main())
