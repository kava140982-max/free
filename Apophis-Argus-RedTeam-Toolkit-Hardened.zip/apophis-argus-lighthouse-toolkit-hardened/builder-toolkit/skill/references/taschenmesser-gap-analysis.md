# Taschenmesser-Analyse und Ergänzungsplan

## Befund aus dem Archiv

Das Archiv enthält eine brauchbare Modulschicht mit 15 JSON-Manifesten, `modkit.js`, einem Selbsttest, einem EUDI-Konformitätsbundle und synthetischen Samples. Besonders wertvoll sind die expliziten Felder für `kind`, `network`, `core_access`, `maturity`, `paths`, `limits`, `tags` und `external_location`. Diese Felder gehören in den generischen Lighthouse-Modulvertrag.

Der direkte Archivtest zeigt aber eine wichtige Grenze: EUDI-Selbsttest und Manifest-Selbsttest bestehen, während `modkit check` im isolierten Taschenmesser-Archiv wegen 18 fehlender `system/`-Pfade scheitert. Die Manifeste sind also als Zusatzpaket für ein Hauptrepository gedacht, nicht als standalone bundle. Der Lighthouse-Baukasten braucht deshalb eine explizite Unterscheidung zwischen `local`, `external` und `missing` sowie einen Katalogtest, der externe Pfade nicht fälschlich als lokale Evidenz ausgibt.

Mehrere vorhandene Module sind `present`, aber nicht einzeln getestet. Für die nächste Reifestufe gehören positive, negative, Boundary-, Abuse-, Authorization-, Tenant-, Data-Routing- und Review-Veto-Fälle in jedes Modul. `maturity: internally_tested` muss konkrete, vorhandene Evidenz referenzieren; `externally_confirmed` braucht eine unabhängige Prüfquelle.

## Was in den Lighthouse-Baukasten gehört

Die neue Katalogschicht übernimmt die starke Taschenmesser-Idee, ergänzt aber Pfadsicherheit, standalone Root, externe Referenzen, Reifegradnachweise und einen maschinenlesbaren Katalog. Der neue Provenance-Generator erzeugt nur **unsignierte** SLSA/in-toto-Metadaten. Signierung und Attestation bleiben CI-Aufgabe.

Zusätzlich gehört ein Evidence-Index für SBOM-Formate und Lebenszyklusphasen hinein. CycloneDX unterstützt Lifecycle-Phasen wie `pre-build`, `build`, `post-build` und `operations` und kann Beziehungen zu VEX, Threat Models, Risikoassessments sowie statischen und dynamischen Analyseberichten abbilden. Ein SBOM ist aber kein Sicherheits- oder Compliance-Beweis.

## Relevante externe Muster

GitHub Artifact Attestations verknüpfen Artefakte mit Workflow, Repository, Environment, Commit und Trigger und können SBOMs verbinden. GitHub weist ausdrücklich darauf hin, dass Attestations verifizierbare Herkunft liefern, aber nicht die Sicherheit des Artefakts garantieren. [1]

SLSA Provenance v1 beschreibt `subject`, `buildDefinition`, externe Parameter, aufgelöste Abhängigkeiten, `builder.id` und eine `invocationId`. Diese Felder ermöglichen eine überprüfbare Antwort darauf, wo, wie und mit welchen Inputs ein Artefakt entstanden ist. [2]

OpenSSF Scorecard deckt über reine Action-Pinning-Prüfung hinaus unter anderem SAST, Schwachstellen, Branch Protection, Code Review, Dependency Updates, Token Permissions, Security Policy, Signed Releases und Fuzzing ab. [3]

in-toto ergänzt die Supply-Chain-Sicht um transparente Schritte, Akteure und Reihenfolge vom Ursprung bis zum Nutzer. [4]

## Priorisierte Ergänzungen

**Sofort:** Katalogvalidator, standalone/external path semantics, Reifegradnachweise, SLSA/in-toto-Provenance-Skeleton, SBOM/VEX-/Threat-Model-Index und Tests für alle vier Gate-Ergebnisse.

**Danach:** GitHub Artifact Attestations zusätzlich zu Cosign-Bundles für veröffentlichte Release-Artefakte, Verifikation auf Verbraucherseite, SARIF-Import, OSV-/Dependency-Review, CodeQL/SAST und Scorecard-Gate.

**Produktionsstufe:** unveränderbarer externer Evidence Store, Schlüssel-/Issuer-Lifecycle, Revocation/Rotation, PostgreSQL-RLS, OIDC-/SAML-Tenant-Claims, Backup-/Restore-Übungen, unabhängiger Read-only-Audit und ein signierter, versionierter Katalog aller Module.

## Grenzen

Das Archiv liefert keine unabhängige externe Bestätigung. Die fehlenden `system/`-Pfade sind kein Beweis, dass die referenzierten Hauptrepo-Dateien schlecht sind; sie zeigen nur, dass das Zusatzpaket allein nicht reproduzierbar prüfbar ist. Die neuen Ergänzungen machen diesen Unterschied maschinenlesbar.

## Quellen

[1]: https://docs.github.com/en/actions/concepts/security/artifact-attestations "GitHub Artifact Attestations"
[2]: https://slsa.dev/spec/v1.2/build-provenance "SLSA v1.2 Build Provenance"
[3]: https://github.com/ossf/scorecard "OpenSSF Scorecard"
[4]: https://in-toto.io/ "in-toto Supply Chain Framework"
[5]: https://cyclonedx.org/docs/1.6/ "CycloneDX v1.6 JSON Reference"
