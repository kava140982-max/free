# Module Factory

## Neues Modul erzeugen

```bash
python scripts/init_module.py research-evidence-planner ./modules/research-evidence-planner
python scripts/run_assurance.py ./modules/research-evidence-planner
python scripts/validate_module.py .
```

Der Scaffolder erzeugt keine fachliche Wahrheit und keine Autorisierung. Er erzeugt ein ausführbares Minimalmodul mit bewusst begrenzter Beispielpolicy. `module.yaml` bleibt `draft`; `policy-evaluation.json` und `test-report.json` bleiben `unverified` bzw. `not_run`, bis der Assurance-Runner die konkrete Implementierung geprüft hat. Der Runner schreibt `artifacts/all-test-results.json` und kennzeichnet externe oder unabhängige Prüfungen separat als `NOT_EXECUTED`.

Für Taschenmesser-artige Modulpakete müssen lokale `paths`, `external_location` und fehlende Pfade unterschieden werden. `external_location` ist eine Referenz, keine lokale Evidenz. Ein Modul mit `maturity: internally_tested` braucht vorhandene Testdateien; `externally_confirmed` braucht einen konkreten externen Bericht.

Nutze für Kataloge `scripts/validate_catalog.py` und `scripts/build_catalog.py`. Nutze für Release-Provenance `scripts/build_provenance.py`; signiere das erzeugte SLSA/in-toto-Dokument erst in einer vertrauenswürdigen CI und verifiziere die Attestation beim Konsumenten.

## Lifecycle

1. Modul-ID und Domänenscope festlegen.
2. Normative Referenz unverändert sichern.
3. Modulmanifest und Rollen festlegen.
4. Security-Profile auswählen.
5. Datenklassen und Routen begrenzen.
6. Input-/Output-Schemas vervollständigen.
7. Fachregeln mit Quellenstatus und Unsicherheit ergänzen.
8. Positive, negative, Missbrauchs- und Grenztests implementieren.
9. Policy- und Traceability-Artefakte erzeugen.
10. Dynamische Tests und unabhängigen Read-only-Audit ausführen.
11. Nur belegte Eigenschaften als `tested` oder `observed` melden.
