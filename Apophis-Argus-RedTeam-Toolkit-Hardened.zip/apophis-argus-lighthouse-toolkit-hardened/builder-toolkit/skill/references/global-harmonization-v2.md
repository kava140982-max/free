# Global Harmonization v2 — ergänzende Herkunftsnotiz

Diese Datei dokumentiert Herkunft und Einschränkungen des gelieferten Entwurfs. Die vollständige, für das Bauen maßgebliche Arbeitsanleitung und alle Tabellen stehen jetzt in `../SKILL.md` (Abschnitte 1–17); die kanonische maschinenlesbare Quelle bleibt `../artifacts/global-harmonization-v2.json`.

# Globale Harmonisierung v2 — Erweiterungsentwurf

**Dokument-ID:** `LH-GLOBAL-2026-11-03`  
**Version:** `2.0.0-draft`  
**Status:** `pending_review` · menschliche Prüfung erforderlich · unsigniert  
**Evidenzbasis laut Vorlage:** Desk-Research und Architektur-Mapping; keine Laufzeitprüfung realer Aufsichts-, Identitäts- oder Produktionssysteme.  
**Hinweis:** not a certification.

## Zweck und Verhältnis zum Basispaket

Diese Erweiterung übernimmt die beigefügte globale Harmonisierungsspezifikation in maschinenlesbarer Form und ergänzt die bestehende v1-Builder-Anleitung um eine vorgeschlagene Referenzarchitektur, Gate-Sequenz, Register, Profile, Gap-Analyse und Roadmap. Sie ist ein **Planungs- und Review-Entwurf**, keine Implementierung der beschriebenen Kontrollen und kein Nachweis, dass externe Standards erfüllt sind.

Die ursprünglichen v1-Dateien und Prüfergebnisse bleiben unverändert. Verbindliche Nutzung setzt eine unabhängige fachliche, rechtliche und sicherheitstechnische Prüfung sowie eine dokumentierte Entscheidung über jede Übernahme voraus. Normausgaben, Geltungsbereiche und Fristen müssen vor Einsatz anhand der jeweiligen Primärquelle verifiziert werden.

## Inhalt

- `../artifacts/global-harmonization-v2.json` — kanonische maschinenlesbare Spezifikation aus der gelieferten HTML-Vorlage.
- `../artifacts/global-harmonization-v2-dashboard.html` — gelieferte interaktive Übersicht, unverändert archiviert.
- Kerndimensionen laut Vorlage: 7 Architektur-Layer, 16 geordnete Gates, 70 Registry-Einträge, 13 Domänenprofile und 37 Gap-Einträge.

## Vorgeschlagene Architektur- und Kontrollbereiche

Die Spezifikation beschreibt Layer für Normen/Traceability, Security-Envelope und Identität, Daten-/Domänenverarbeitung, Policy-as-Code, Review-Adapter sowie Evidenz/Observability/Anker. Sie schlägt Gates für Umgebung und Integrität, SBOM/Lizenz, Signatur/Attestation, Autorisierung, Tenant-/Objektgrenzen, Datenroute/Residenz, Kryptografie/PQC, VEX, Safety/Injection/Exportkontrolle, Modellroute, Domänenlogik, Policy, menschliche Reviews, Output-Vertrag, Evidenz/Provenance und abschließende Freigabe vor.

Diese Bezeichnungen sind Soll-Entwurf. Ein Gate gilt erst dann als implementiert, wenn es in einer konkreten Revision technisch umgesetzt und durch passende, dokumentierte Tests belegt wurde. Nicht ausführbare bzw. externe Prüfungen bleiben `NOT_EXECUTED`/`STATIC_INSPECTION_PENDING`; sie dürfen nicht als bestanden gezählt werden.

## Sichere Übernahmefolge

1. Spezifikation und alle Normverweise gegen Primärquellen prüfen; Versionskonflikte und Rechtsraum dokumentieren.
2. Kontroll-Mapping gegen bestehende Verträge/Tests durchführen und Änderungen mit Verantwortlichen freigeben.
3. Pro Gate Owner, Eingaben, Entscheidung, Fail-Status, Testmethode, Evidenzklasse und unabhängige Reviewer festlegen.
4. Nur synthetische Fixtures und lokale Tests zum ersten Prototyp verwenden; niemals echte Produktions-/Kundendaten in dieses Harness einbringen.
5. Die v2-Sollsequenz zunächst nur als Kontrollplan abbilden; keine Gate- oder Statusaussage aus dem Dashboard als tatsächliche Laufzeiteigenschaft übernehmen.
6. Vor jeder consequential Nutzung unabhängige Domain-, Security/Safety- und Red-Team-/Uncertainty-Reviews planen. Externe Tests nur mit schriftlicher Scope-Freigabe.
7. Änderungsset, Prüfergebnisse, offene Punkte, Revision und Grenzen dokumentieren. Keine Freigabe bei fehlender Pflicht-Evidenz oder ausstehender erforderlicher Prüfung.

## Evidenz und Grenzen

Die Vorlage führt die Resultate `PASS`, `PASS_WITH_LIMITATIONS` und `NOT_EXECUTED` getrennt auf. Ihre lokalen synthetischen Resultate sind, soweit in der Vorlage behauptet, **übernommene Angaben und in dieser Paketaufwertung nicht erneut verifiziert**. Signaturprüfung, SBOM-Validierung, Policy-Engine-Äquivalenz, Identitätsprovider-Verifikation, unabhängige Reviews, Labor-/Feldtests und Zertifizierung werden nicht als erbracht behandelt.

Keine Aussage in dieser Erweiterung bescheinigt Sicherheit, Konformität, Akkreditierung, Zertifizierung, Produktionsreife oder internationale Anerkennung. Aufwand, Termine, KPIs und Norm-Mappings aus der Vorlage sind Planungsannahmen, keine gemessenen Ergebnisse oder verbindlichen Zusagen.
