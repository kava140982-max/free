# Message-, Output- und Audit-Verträge

## Input-Mindestfelder

```json
{
  "schema": "apophis/module-request/v1",
  "message_id": "uuid",
  "conversation_id": "uuid",
  "actor_id": "verified-or-unavailable",
  "actor_role": "role",
  "authorization_id": "external-approval-id",
  "task": "allowed-enum",
  "data_class": "public_research",
  "model_route": "local",
  "context_payload": {}
}
```

Bei fehlender `authorization_id` darf ein Modul mit erforderlicher Autorisierung nicht rechnen oder inferieren.

Unterscheide strukturellen und semantischen Fehler: Fehlt das Pflichtfeld, lautet die Entscheidung `invalid_request` mit `SCHEMA-01`. Ist das Feld vorhanden, aber leer, oder kann die Autorisierung nicht verifiziert werden, lautet die Entscheidung `denied` mit `AUTH-01`. Eine Autorisierung darf nie aus Rolle, Kontext oder Modellwissen inferiert werden.

## Erfolgsoutput

Setze immer `status: pending_review` und `requires_human_review: true`. Führe `traceability_id`, `authorization_id`, Safety-Flags, Annahmen, Quellenstatus und Restunsicherheit mit.

## Ablehnung

```json
{
  "schema": "apophis/module-suggestion/v1",
  "message_id": "...",
  "module_id": "...",
  "module_version": "...",
  "status": "denied",
  "requires_human_review": true,
  "authorization": {"verified": false, "authorization_id": null},
  "safety": {"passed": false, "flags": ["SAFE-01"]},
  "deliverables": {},
  "limitations_and_assumptions": ["No operational instructions provided."],
  "sources_and_rationale": [],
  "traceability_id": "..."
}
```

## Auditrecord

Jede Ausführung erzeugt mindestens:

```json
{
  "schema": "apophis/module-audit/v1",
  "traceability_id": "...",
  "message_id": "...",
  "authorization_id": "...",
  "module_id": "...",
  "input_sha256": "...",
  "policy_version": "...",
  "model_route": "local",
  "decision": "pending_review",
  "review_adapters": [],
  "evidence": [],
  "created_at": "..."
}
```

Der kanonische Assurance-Report verwendet `schema: apophis/consolidated-test-results/v1` und enthält immer die getrennten Bereiche `executed` und `planned_not_executed`. Ein geplanter Test darf nicht als `tested` erscheinen. Der Report darf `PASS_WITH_LIMITATIONS` verwenden, wenn lokale Prüfungen bestanden wurden, aber unabhängige, externe oder produktive Evidenz fehlt.
