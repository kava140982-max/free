# Assurance Runner

Use `python scripts/run_assurance.py <module-root>` as the default module-wide verification command. It writes exactly one consolidated report to `artifacts/all-test-results.json` unless `--output` is supplied.

## Execution contract

The runner is not a sandbox. It executes module-supplied unittest code and `policy/evaluate.py` as the current user; inspect all code first and use a disposable, unprivileged, network-isolated environment with external resource limits. The current runner has no robust CPU/memory/process-group limits, and captures subprocess output in memory before truncating it for the report. Do not use untrusted modules, real secrets, or sensitive fixtures. It does not silently repair source files. Treat stdout/stderr and parser errors as untrusted and potentially sensitive.

```json
{
  "schema": "apophis/consolidated-test-results/v1",
  "overall_verdict": "PASS_WITH_LIMITATIONS",
  "not_a_certification": true,
  "executed": {},
  "planned_not_executed": []
}
```

`PASS` means every executed check passed and no planned check remains relevant. `PASS_WITH_LIMITATIONS` means executed checks passed but independent, external or production evidence is still absent. `FAILED` means an executed check failed. `BLOCKED` is reserved for an explicit external prerequisite that prevented a required check; it is not a synonym for a failing test.

## Required distinctions

- `tested`: a direct executable probe passed.
- `observed`: a declaration or static property was read, not behaviorally proven.
- `unverified`: no adequate probe exists.
- `NOT_EXECUTED`: the check is planned but was not run, with a reason.
- `proven` and `compliant`: do not use for local module tests.

## Snapshot rule

The current read-only inventory hash covers only the existing regular files from the hard-coded `required` list; it does not recursively cover every source, policy, test or fixture. It excludes the generated report. Do not describe it as a complete source/test snapshot. Symlinks and caller-selected output paths require additional scope controls; use a disposable copy and a new output directory.

## Authorization edge cases

Handle these separately:

- missing structural field -> `invalid_request` / `SCHEMA-01`;
- present but empty authorization -> `denied` / `AUTH-01`;
- present but unverifiable authorization -> `denied` / `AUTH-01`;
- verified authorization -> continue through the remaining gates.
