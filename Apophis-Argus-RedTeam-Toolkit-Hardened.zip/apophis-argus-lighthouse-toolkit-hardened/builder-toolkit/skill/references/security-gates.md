# Security Envelope und Stop Conditions

## Gate-Reihenfolge

1. Umgebung und Integrität prüfen.
2. Autorisierung und Rolle verifizieren.
3. Tenant-, Objekt- und Zweckbindung prüfen.
4. Datenklasse und Route prüfen.
5. Prompt-/Input-Injection und forbidden intents prüfen.
6. Domänenlogik ausführen.
7. Review-Adapter ausführen.
8. Output-Schema validieren.
9. Audit-Evidenz schreiben.
10. Erst danach Vorschlag ausgeben.

## Standard-Stop-Conditions

| ID | Bedingung | Status | Aktion |
|---|---|---|---|
| AUTH-01 | Signatur fehlt oder ist ungültig | denied | keine Domänenlogik |
| ENV-01 | Image/SBOM/Originalzustand nicht verifiziert | blocked | Umgebung reparieren |
| DATA-01 | Datenklasse nicht für Route freigegeben | blocked | lokale sichere Route oder Ablehnung |
| TENANT-01 | Tenant fehlt, ungültig oder fremd | denied | keine Objektauflösung |
| SAFE-01 | Verbotene oder gefährlich operative Absicht | denied | sichere Alternative |
| SCHEMA-01 | Input-/Output-Vertrag verletzt | invalid_request | keine Inferenz |
| REVIEW-01 | Kritischer Reviewer-Befund | denied | Audit und menschliche Entscheidung |
| EVID-01 | erforderliche Evidenz fehlt | blocked | keine PASS-Aussage |
| KILL-01 | externer Kill-Switch oder Heartbeat verletzt | denied | Prozess beenden, Audit sichern |

## Datenrouting

- `public_research`: lokal oder API, wenn keine weiteren Einschränkungen gelten.
- `internal_research`: lokal; externe Route nur nach expliziter Freigabe und Datenminimierung.
- `clinical_pii`: standardmäßig ablehnen; keine API-Route.
- `classified`: ablehnen und auditieren.

## Sicherheitsantwort

Lehne knapp ab. Wiederhole keine sensiblen Eingabedetails. Liefere nur eine sichere, nicht-operative Alternative und eine Audit-ID.
