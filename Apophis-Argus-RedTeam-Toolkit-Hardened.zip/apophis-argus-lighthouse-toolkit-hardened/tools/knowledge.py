#!/usr/bin/env python3
"""Append-only, local pattern notebook for AI/human retrieval. No network/LLM use."""
from __future__ import annotations
import argparse, hashlib, json, re, sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT=Path(__file__).resolve().parents[1]
STORE=ROOT/'knowledge'/'patterns.jsonl'
SEEDS=ROOT/'knowledge'/'seed-patterns.json'
GENESIS='GENESIS'
EVIDENCE={'proven','compliant','tested','observed','declared','unverified','failed','NOT_EXECUTED','BLOCKED','PASS_WITH_LIMITATIONS'}

def canonical(value: Any) -> bytes:
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf-8')

def digest(value: Any) -> str:
    return hashlib.sha256(canonical(value)).hexdigest()

def read_store(path: Path=STORE) -> list[dict[str,Any]]:
    if not path.exists(): return []
    records=[]; previous=GENESIS
    for line_no,line in enumerate(path.read_text(encoding='utf-8').splitlines(),1):
        if not line.strip(): continue
        try: r=json.loads(line)
        except json.JSONDecodeError as exc: raise ValueError(f'invalid JSONL at line {line_no}: {exc}') from exc
        if not isinstance(r,dict) or 'record_hash' not in r: raise ValueError(f'invalid record shape at line {line_no}')
        claimed=r['record_hash']; body={k:v for k,v in r.items() if k!='record_hash'}
        if body.get('sequence')!=len(records)+1: raise ValueError(f'sequence mismatch at line {line_no}')
        if body.get('previous_hash')!=previous: raise ValueError(f'broken previous_hash at line {line_no}')
        actual=digest(body)
        if claimed!=actual: raise ValueError(f'record hash mismatch at line {line_no}')
        previous=claimed; records.append(r)
    return records

def append_one(item: dict[str,Any], path: Path=STORE) -> dict[str,Any]:
    path.parent.mkdir(parents=True,exist_ok=True)
    records=read_store(path)
    if any(r['pattern_id']==item['pattern_id'] for r in records):
        raise ValueError(f"duplicate pattern_id: {item['pattern_id']}")
    body={"schema_version":"apophis-pattern/v1","sequence":len(records)+1,
          "pattern_id":item['pattern_id'],"recorded_at_utc":datetime.now(timezone.utc).isoformat(),
          "title":item['title'],"pattern":item['pattern'],"lesson":item['lesson'],
          "evidence_class":item['evidence_class'],"claim_status":item.get('claim_status','observed'),
          "source_refs":item['source_refs'],"tags":item.get('tags',[]),
          "supersedes":item.get('supersedes'),"previous_hash":records[-1]['record_hash'] if records else GENESIS}
    if body['evidence_class'] not in EVIDENCE: raise ValueError('unsupported evidence class')
    record={**body,"record_hash":digest(body)}
    line=canonical(record).decode('utf-8')+'\n'
    if len(line.encode('utf-8'))>65536: raise ValueError('record exceeds 64 KiB limit')
    # Single-writer local file; append-only by this CLI, not WORM or tamper-proof.
    with path.open('a',encoding='utf-8',newline='\n') as f:
        f.write(line); f.flush()
    return record

def cmd_seed(args):
    seeds=json.loads(SEEDS.read_text(encoding='utf-8'))
    current=read_store(); ids={r['pattern_id'] for r in current}; added=0
    for item in seeds:
        if item['pattern_id'] in ids: continue
        append_one(item); ids.add(item['pattern_id']); added+=1
    print(json.dumps({"status":"ok","added":added,"total":len(read_store()),"store":str(STORE)},ensure_ascii=False))

def cmd_add(args):
    records=read_store(); next_id=f"PAT-{len(records)+1:04d}"
    item={"pattern_id":next_id,"title":args.title,"pattern":args.pattern,"lesson":args.lesson,
          "evidence_class":args.evidence_class,"claim_status":args.claim_status,
          "source_refs":args.source,"tags":args.tag or [],"supersedes":args.supersedes}
    r=append_one(item); print(json.dumps(r,ensure_ascii=False,sort_keys=True))

def cmd_query(args):
    records=read_store(); terms=[x.casefold() for x in re.findall(r'[\w-]+',args.query,flags=re.UNICODE)]
    matches=[]
    for r in records:
        hay=' '.join([r['title'],r['pattern'],r['lesson'],' '.join(r.get('tags',[])),' '.join(r.get('source_refs',[]))]).casefold()
        score=sum(1 for t in terms if t in hay)
        if score: matches.append((score,r))
    matches.sort(key=lambda x:(-x[0],x[1]['sequence']))
    print(json.dumps({"query":args.query,"result_count":min(len(matches),args.limit),"total_matches":len(matches),"records":[r for _,r in matches[:args.limit]]},ensure_ascii=False,indent=2))

def cmd_verify(args):
    records=read_store(); print(json.dumps({"status":"PASS","records":len(records),"tip":records[-1]['record_hash'] if records else GENESIS,"store":"knowledge/patterns.jsonl","integrity_scope":"local SHA-256 chain only; full rewrite is possible"},ensure_ascii=False))

def cmd_list(args):
    records=read_store(); print(json.dumps([{"pattern_id":r['pattern_id'],"title":r['title'],"evidence_class":r['evidence_class'],"tags":r['tags']} for r in records],ensure_ascii=False,indent=2))

def main():
    p=argparse.ArgumentParser(description=__doc__); sub=p.add_subparsers(dest='command',required=True)
    s=sub.add_parser('seed',help='append packaged initial patterns without replacing existing records'); s.set_defaults(func=cmd_seed)
    a=sub.add_parser('add',help='append one new finding/pattern'); a.add_argument('--title',required=True); a.add_argument('--pattern',required=True); a.add_argument('--lesson',required=True); a.add_argument('--source',action='append',required=True,help='source ref; repeat as needed'); a.add_argument('--evidence-class',choices=sorted(EVIDENCE),default='observed'); a.add_argument('--claim-status',choices=['observed','declared','tested','unverified','NOT_EXECUTED','BLOCKED'],default='observed'); a.add_argument('--tag',action='append'); a.add_argument('--supersedes'); a.set_defaults(func=cmd_add)
    q=sub.add_parser('query',help='search title, pattern, lesson, tags and source refs'); q.add_argument('--query',required=True); q.add_argument('--limit',type=int,default=10); q.set_defaults(func=cmd_query)
    v=sub.add_parser('verify',help='verify JSONL sequence and SHA-256 hash chain'); v.set_defaults(func=cmd_verify)
    l=sub.add_parser('list',help='list pattern index'); l.set_defaults(func=cmd_list)
    args=p.parse_args()
    try: args.func(args)
    except (ValueError,FileNotFoundError,json.JSONDecodeError) as e:
        print(f'ERROR: {e}',file=sys.stderr); return 2
    return 0

if __name__=='__main__': raise SystemExit(main())
