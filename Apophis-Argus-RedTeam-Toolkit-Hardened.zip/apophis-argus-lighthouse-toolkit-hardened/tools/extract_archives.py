#!/usr/bin/env python3
"""Safely unpack an archive and every nested ZIP into separate, auditable trees.
No extracted scripts or files are executed. Standard library only.
"""
from __future__ import annotations
import argparse, hashlib, json, re, stat, zipfile
from pathlib import Path, PurePosixPath

MAX_TOTAL_BYTES = 50 * 1024 * 1024
MAX_ARCHIVE_COUNT = 20
MAX_DEPTH = 4

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def safe_name(name: str) -> PurePosixPath:
    name = name.replace('\\', '/')
    p = PurePosixPath(name)
    if not name or name.startswith('/') or re.match(r'^[A-Za-z]:', name) or any(part in ('..', '') for part in p.parts):
        raise ValueError(f'unsafe archive path: {name!r}')
    return p

def extract_one(blob: bytes, destination: Path, logical_name: str) -> tuple[list[dict], list[tuple[Path, bytes]]]:
    entries=[]; nested=[]; total=0; seen=set()
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(__import__('io').BytesIO(blob)) as z:
        bad=z.testzip()
        if bad: raise ValueError(f'CRC failure in {logical_name}: {bad}')
        for info in z.infolist():
            rel=safe_name(info.filename)
            key=str(rel)
            if key in seen: raise ValueError(f'duplicate archive entry {key!r}')
            seen.add(key)
            mode=info.external_attr >> 16
            if stat.S_ISLNK(mode): raise ValueError(f'symlink forbidden in archive: {key}')
            total += info.file_size
            if total > MAX_TOTAL_BYTES: raise ValueError('uncompressed archive exceeds 50 MiB safety cap')
            target=destination.joinpath(*rel.parts)
            if not target.resolve().is_relative_to(destination.resolve()): raise ValueError(f'path escaped destination: {key}')
            if info.is_dir() or info.filename.endswith('/'):
                target.mkdir(parents=True,exist_ok=True)
                entries.append({'path':key,'kind':'directory','size':0})
                continue
            target.parent.mkdir(parents=True,exist_ok=True)
            data=z.read(info)
            target.write_bytes(data)
            entries.append({'path':key,'kind':'file','size':len(data),'sha256':sha256_bytes(data)})
            if key.lower().endswith('.zip'):
                nested.append((target,data))
    return entries,nested

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('source_zip',type=Path)
    ap.add_argument('output_dir',type=Path)
    args=ap.parse_args()
    src=args.source_zip.resolve(); out=args.output_dir.resolve()
    if not src.is_file(): raise SystemExit(f'archive not found: {src}')
    if out.exists() and any(out.iterdir()): raise SystemExit(f'output directory must be empty: {out}')
    out.mkdir(parents=True,exist_ok=True)
    original=src.read_bytes()
    manifest={'source':src.name,'source_sha256':sha256_bytes(original),'executed_extracted_content':False,'archives':[]}
    queue=[(original,Path('main'),src.name,0)]
    extracted_count=0
    cumulative_bytes=0
    while queue:
        blob,rel_dir,logical_name,depth=queue.pop(0)
        if depth>MAX_DEPTH: raise SystemExit('nested archive depth limit exceeded')
        extracted_count += 1
        if extracted_count>MAX_ARCHIVE_COUNT: raise SystemExit('nested archive count limit exceeded')
        dest=out/'extracted'/rel_dir
        entries,nested=extract_one(blob,dest,logical_name)
        uncompressed=sum(e['size'] for e in entries)
        cumulative_bytes += uncompressed
        if cumulative_bytes > MAX_TOTAL_BYTES: raise SystemExit('cumulative nested expansion exceeds 50 MiB safety cap')
        manifest['archives'].append({'name':logical_name,'depth':depth,'extracted_to':rel_dir.as_posix(),'entries':len(entries),'entry_files':sum(e['kind']=='file' for e in entries),'uncompressed_bytes':uncompressed,'cumulative_uncompressed_bytes':cumulative_bytes,'entry_manifest':entries})
        for nested_path,nested_blob in nested:
            subrel=nested_path.relative_to(out/'extracted').with_suffix('')
            queue.append((nested_blob,Path('nested')/subrel,nested_path.name,depth+1))
    report=out/'extraction-report.json'
    report.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(f"Extracted {extracted_count} archive(s); content was not executed. Report: {report}")

if __name__=='__main__': main()
