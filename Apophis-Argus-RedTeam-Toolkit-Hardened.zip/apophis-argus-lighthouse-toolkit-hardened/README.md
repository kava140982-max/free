# Apophis Argus RedTeam Toolkit — Hardened Release

Dies ist ein kuratiertes, offline-only Forschungs-/Testpaket. Es ist keine Zertifizierung, keine Produktionsfreigabe und kein Ersatz für unabhängige Reviews.

## Sicherheitsänderungen

Der Assurance-Runner ist standardmäßig `BLOCKED`. Zielcode wird nur bei explizitem `--execute` gestartet und nur, wenn `unshare` für einen isolierten Netzwerk-Namespace verfügbar ist. CPU-, Adressraum-, Dateigrößen-, Wall-Time- und Ausgabegrenzen werden gesetzt. Ohne diese Voraussetzungen wird nicht simuliert und nicht ausgeführt.

Manifest- und Katalogpfade sind symlink-sicher auf den deklarierten Root begrenzt. Katalogwerte werden vor Markdown-Ausgabe escaped. JSON-Duplikatschlüssel werden abgewiesen. Der Modul-Scaffolder verweigert symlinkbasierte Zielpfade.

## Ausgeschlossene Inhalte

`BUILD-EXCLUDES.txt` dokumentiert den Release-Scope. Historische Duplikate, Originalarchive, verschachtelte ZIPs, Bytecode, generierte Dashboards und untrusted Prompt-Fixtures werden nicht in den Hardened Release übernommen.

## Verifikation

```bash
python3 -m unittest discover -s argus-100/tests -p 'test_*.py'
python3 argus-100/scripts/run_assurance.py argus-100
```

Der zweite Befehl muss ohne verfügbare Isolation `PASS_WITH_LIMITATIONS` mit BLOCKED-Teilprüfungen liefern; ein positives Testergebnis ist keine Zertifizierung.
