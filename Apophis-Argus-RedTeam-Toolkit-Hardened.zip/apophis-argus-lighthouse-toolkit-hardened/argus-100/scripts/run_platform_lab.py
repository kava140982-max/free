#!/usr/bin/env python3
"""Run a deterministic multi-module policy laboratory."""
import json
import sys
from pathlib import Path

DECISIONS = {"pending_review", "denied", "blocked", "invalid_request"}

def evaluate(case):
    if case.get("schema_invalid"):
        return "invalid_request", "SCHEMA-01"
    if not case.get("authorization_verified", False):
        return "denied", "AUTH-01"
    if case.get("tenant_mismatch"):
        return "denied", "TENANT-01"
    if case.get("forbidden_intent"):
        return "denied", "SAFE-01"
    if case.get("data_class") in {"clinical_pii", "classified"}:
        return "blocked", "DATA-01"
    if case.get("data_class") == "internal_research" and case.get("model_route") == "api":
        return "blocked", "DATA-01"
    if case.get("external_write"):
        return "denied", "AUTH-01"
    if case.get("critical_review_finding"):
        return "denied", "REVIEW-01"
    return "pending_review", None

def main():
    path = Path(sys.argv[1] if len(sys.argv) > 1 else Path(__file__).resolve().parents[1] / "examples" / "maximal-platform" / "platform.json")
    spec = json.loads(path.read_text(encoding="utf-8"))
    failures = []
    modules = spec.get("modules", [])
    module_ids = [module.get("module_id") for module in modules]
    if len(module_ids) != len(set(module_ids)):
        failures.append("duplicate_module_id")
    for module in modules:
        for field in ("module_id", "domain", "risk_level", "allowed_tasks", "forbidden_tasks", "security_profile"):
            if not module.get(field):
                failures.append(f"module_missing:{module.get('module_id')}:{field}")
        if module.get("not_a_certification") is not True:
            failures.append(f"module_not_marked:{module.get('module_id')}")
    passed = 0
    for case in spec.get("cases", []):
        actual, gate = evaluate(case)
        expected = case.get("expected_status")
        if expected not in DECISIONS or actual != expected:
            failures.append(f"case_failed:{case.get('case_id')}:expected={expected}:actual={actual}:gate={gate}")
        else:
            passed += 1
    result = {
        "schema": "apophis/platform-lab-report/v1",
        "verdict": "FAILED" if failures else "PASS",
        "platform": spec.get("platform_id"),
        "modules": len(modules),
        "cases": len(spec.get("cases", [])),
        "cases_passed": passed,
        "decision_coverage": sorted({case.get("expected_status") for case in spec.get("cases", [])}),
        "failures": failures,
        "not_a_certification": True,
    }
    print(json.dumps(result, indent=2))
    return 1 if failures else 0

if __name__ == "__main__":
    raise SystemExit(main())
