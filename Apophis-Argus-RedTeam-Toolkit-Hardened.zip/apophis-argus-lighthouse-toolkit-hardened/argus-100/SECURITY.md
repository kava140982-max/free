# Argus-100 Security Boundary

> `not_a_certification: true`. Dieses Projekt ist ein synthetischer lokaler Testkörper und kein Sicherheitsprüfer für reale bio-, KRITIS-, Medizin-, Lieferketten- oder Tenant-Systeme.

## Nichtziele

Keine Erregerkultivierung/-optimierung, medizinische Dosierung, SCADA-/Reaktorsteuerung, Produktionsänderung, Release-Signierung, Veröffentlichung, Deployment oder echte Datenverarbeitung. Kein Netzwerk, IdP, Signaturdienst, Tenant-System oder Provider wird angesprochen.

## Untrusted Fixture-Grenze

`tests/fixtures.json` enthält präparierte, teils absichtlich feindselige Strings für Tests. Sie werden nur an eine lokale deterministische Policy übergeben. CN, EN, RU, DE und AR sind mit statischen Markern abgedeckt; das ist kein allgemeiner Injection-Detektor. Sensitive/forbidden Domain-Strings sind kurze harmlose Testlabels, keine operationalen Inhalte. Rohtexte werden nicht in Ergebnisberichte gespiegelt.

Cross-module-Fälle verändern Testmetadaten (Tenant/Auth/Data-Class) und prüfen die lokale Policy-Ablehnung; sie implementieren keine echte Modulverkettung oder sichere Metadaten-Weitergabe. Replay, Zeitstempel und Selbstattestierung werden ebenfalls nur anhand synthetischer Felder simuliert; keine kryptografische Signatur/Replay-Cache/vertrauenswürdige Uhr ist vorhanden.

## Laufzeitgrenze

Der Assurance-Runner startet Python-Code unter dem aktuellen Nutzer. Er ist keine Sandbox und besitzt keine belastbaren CPU-/Speicher-/Prozesslimits. `unshare -n` war in der Umgebung nicht verfügbar/erlaubt. Der geprüfte Harness-Pfad enthält keine Netzwerkaufrufe; ein OS-seitiges Egress-Verbot wurde nicht technisch erzwungen. Lauf nur in einer kurzlebigen, unprivilegierten Umgebung wiederholen.

## Offene Prüfungen

Kernel-Isolation/Egress-Monitoring, unabhängiges Security-/Domain-/Red-Team-Review, reale IdP-/Signatur-/Provenance-Prüfung, Security-Property der echten Cross-Module-Kette, externe Tests, Feld-/Labor-/Produktionstest und Zertifizierung: `NOT_EXECUTED`. Lokale Tests liefern keine Konformitäts- oder Freigabeaussage.
